using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BackgroundScript : MonoBehaviour {

    public static bool[] availableWeapons { get; private set; }

    public static int emeralds { get; private set; }
    public static int amethysts { get; private set; }

    public static int bestRound { get; set; }

    public static bool showBubbleLevel { get; set; }

    private static SaveData data;

    private void Start() {
        AudioHandler.Init();
        Screen.fullScreen = true;
        LoadSaveData();
        SceneManager.LoadScene("Menu", LoadSceneMode.Additive);
        showBubbleLevel = false;
    }

    public static void ToGameScene() {
        SceneManager.LoadScene("Game", LoadSceneMode.Additive);
        SceneManager.UnloadSceneAsync("Menu");
    }

    public static void ToMenuScene() {
        SceneManager.LoadScene("Menu", LoadSceneMode.Additive);
        SceneManager.UnloadSceneAsync("Game");
    }

    public static void Quit() {
        UpdateSaveData();
        Application.Quit();
        AndroidJavaObject activity = new AndroidJavaClass("com.unity3d.player.UnityPlayer").GetStatic<AndroidJavaObject>("currentActivity");
        activity.Call("finish");
        }

    public static void UpdateSaveData() {

        data.UpdateData(availableWeapons, emeralds, amethysts, bestRound);

        DataManager.SaveData(data);

    }

    public static void LoadSaveData() {

        data = DataManager.LoadData();

        if (data == null) {
            availableWeapons = new bool[30];
            for (int i = 0; i < 30; i++)
                availableWeapons[i] = false;
            availableWeapons[0] = true;

            emeralds = 0;
            amethysts = 0;
            bestRound = 0;

        } else {

            if (data.availableWeapons == null) {
                availableWeapons = new bool[30];
                for (int i = 0; i < 30; i++)
                    availableWeapons[i] = false;
                availableWeapons[0] = true;
            } else availableWeapons = data.availableWeapons;

            emeralds = data.emeralds;
            amethysts = data.amethysts;
            bestRound = data.bestRound;

            // TEMP
            emeralds = 10000;
            amethysts = 1000;
        }
        /*
        for (int i = 0; i < 30; i++)
            availableWeapons[i] = true;
        */

        /*
        availableWeapons = new bool[30];
            for (int i = 0; i < 30; i++)
                availableWeapons[i] = false;
            availableWeapons[0] = true;

            emeralds = 0;
            amethysts = 0;
            bestRound = 0;
        */

        DataManager.SaveData(new SaveData(availableWeapons, emeralds, amethysts, bestRound));
    }

    public static bool AddEmeralds(int value) {
        if (emeralds + value < 0) return false;
        emeralds += value;
        if (emeralds > Util.MAX_INT) emeralds = Util.MAX_INT;

        BackgroundScript.UpdateSaveData();
        return true;
    }

    public static bool AddAmethysts(int value) {
        if (amethysts + value < 0) return false;
        amethysts += value;
        if (amethysts > Util.MAX_INT) amethysts = Util.MAX_INT;

        BackgroundScript.UpdateSaveData();
        return true;
    }

}
