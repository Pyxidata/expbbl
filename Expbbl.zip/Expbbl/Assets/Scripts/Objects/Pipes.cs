using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pipes : MonoBehaviour {

    public static Vector2 leftSpawnPos = new Vector2(-38, 14);
    public static Vector2 topLeftSpawnPos = new Vector2(-20, 28);
    public static Vector2 topRightSpawnPos = new Vector2(20, 28);
    public static Vector2 rightSpawnPos = new Vector2(38, 14);

    public static Vector2 leftSpawnVel = new Vector2(40, 5);
    public static Vector2 topLeftSpawnVel = new Vector2(10, -30);
    public static Vector2 topRightSpawnVel = new Vector2(-10, -30);
    public static Vector2 rightSpawnVel = new Vector2(-40, 5);

    [SerializeField] private GameObject left;
    [SerializeField] private GameObject topLeft;
    [SerializeField] private GameObject topRight;
    [SerializeField] private GameObject right;

    private Animator leftAni;
    private Animator topLeftAni;
    private Animator topRightAni;
    private Animator rightAni;

    private SpriteRenderer leftSR;
    private SpriteRenderer topLeftSR;
    private SpriteRenderer topRightSR;
    private SpriteRenderer rightSR;

    private void Awake() {
        leftAni = left.GetComponent<Animator>();
        topLeftAni = topLeft.GetComponent<Animator>();
        topRightAni = topRight.GetComponent<Animator>();
        rightAni = right.GetComponent<Animator>();

        leftSR = left.GetComponent<SpriteRenderer>();
        topLeftSR = topLeft.GetComponent<SpriteRenderer>();
        topRightSR = topRight.GetComponent<SpriteRenderer>();
        rightSR = right.GetComponent<SpriteRenderer>();
    }

    public void Pump() {
        leftAni.Play("Animate");
        topLeftAni.Play("Animate");
        topRightAni.Play("Animate");
        rightAni.Play("Animate");
    }

    public void SetColor(Color color) {
        leftSR.color = color;
        topLeftSR.color = color;
        topRightSR.color = color;
        rightSR.color = color;
    }

}