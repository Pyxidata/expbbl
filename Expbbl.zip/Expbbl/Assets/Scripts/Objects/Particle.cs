using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Particle : MonoBehaviour {

    public static void Spark(Vector2 pos, int damage) {
        var spark = Instantiate(Resources.Load("Prefabs/Particles/Spark")) as GameObject;
        spark.transform.position = pos;
        var emis = spark.GetComponent<ParticleSystem>().emission;
        emis.SetBurst(0, new ParticleSystem.Burst(0.0f, Mathf.Sqrt(damage)));
    }

    public static void BubblePop(Vector2 pos, int level) {
        var pop = Instantiate(Resources.Load("Prefabs/Particles/Pop")) as GameObject;
        pop.transform.position = pos;
        var emis = pop.GetComponent<ParticleSystem>().emission;
        emis.SetBurst(0, new ParticleSystem.Burst(0.0f, Mathf.Sqrt(level * level * 10)));
    }

    public static void BrickBreak(Vector2 pos, int count, Color color) {
        var debris = Instantiate(Resources.Load("Prefabs/Particles/Debris")) as GameObject;
        debris.transform.position = pos;
        var main = debris.GetComponent<ParticleSystem>().main;
        main.startColor = color;
        var emis = debris.GetComponent<ParticleSystem>().emission;
        emis.SetBurst(0, new ParticleSystem.Burst(0.0f, count));
    }
}
