using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Environment : MonoBehaviour {

    public const int ENV_FIELD = 1;
    public const int ENV_FOREST = 2;
    public const int ENV_MOUNTAIN = 3;
    public const int ENV_ICE = 4;
    public const int ENV_CAVE = 5;
    public const int ENV_LAVA = 6;
    public const int ENV_VOID = 7;
    public const int ENV_SPACE = 8;
    private int currEnv;

    public static Color COL_FIELD = new Color(0.788f, 0.921f, 1.0f, 1.0f);
    public static Color COL_FOREST = new Color(0.77f, 0.94f, 0.85f, 1.0f);
    public static Color COL_MOUNTAIN = new Color(0.8f, 0.84f, 0.89f, 1.0f);
    public static Color COL_ICE = new Color(0.82f, 0.83f, 1.0f, 1.0f);
    public static Color COL_CAVE = new Color(0.59f, 0.51f, 0.63f, 1.0f);
    public static Color COL_LAVA = new Color(0.98f, 0.8f, 0.73f, 1.0f);
    public static Color COL_VOID = new Color(0.67f, 0.56f, 0.74f, 1.0f);
    public static Color COL_SPACE = new Color(0.46f, 0.45f, 0.58f, 1.0f);
    public static Color DEFAULT_COLOR = COL_FIELD;

    private Color color;

    [SerializeField] public GameObject backgrounds;
    private SpriteRenderer frontSR;
    private SpriteRenderer middleSR;
    private SpriteRenderer back1SR;
    private SpriteRenderer back2SR;
    private SpriteRenderer back3SR;
    private SpriteRenderer backgroundSR;

    [SerializeField] public GameObject bricksContainer;
    private SpriteRenderer[] brickSRs;

    [SerializeField] public GameObject ceiling;
    [SerializeField] public GameObject ground;
    private SpriteRenderer groundSR;
    [SerializeField] public GameObject pipesObject;
    private Pipes pipes;

    private void Awake() {
        currEnv = ENV_FIELD;
        color = Color.white;

        frontSR = backgrounds.transform.GetChild(0).GetComponent<SpriteRenderer>();
        middleSR = backgrounds.transform.GetChild(1).GetComponent<SpriteRenderer>();
        back1SR = backgrounds.transform.GetChild(2).GetComponent<SpriteRenderer>();
        back2SR = backgrounds.transform.GetChild(3).GetComponent<SpriteRenderer>();
        back3SR = backgrounds.transform.GetChild(4).GetComponent<SpriteRenderer>();
        backgroundSR = backgrounds.transform.GetChild(5).GetComponent<SpriteRenderer>();

        pipes = pipesObject.GetComponent<Pipes>();
        groundSR = ground.GetComponent<SpriteRenderer>();

        GenerateBricks();
        UpdateBackground();
    }

    public void Reset() {
        currEnv = ENV_FIELD;
        color = Color.white;
        GenerateBricks();
        UpdateBackground();
    }

    public Color NextEnvironment() {
        if (currEnv < ENV_SPACE) currEnv++;
        UpdateBackground();
        VaryEnvironment();

        switch (currEnv) {
            case ENV_FIELD: return COL_FIELD;
            case ENV_FOREST: return COL_FOREST;
            case ENV_MOUNTAIN: return COL_MOUNTAIN;
            case ENV_ICE: return COL_ICE;
            case ENV_CAVE: return COL_CAVE;
            case ENV_LAVA: return COL_LAVA;
            case ENV_VOID: return COL_VOID;
            case ENV_SPACE: return COL_SPACE;
            default: return DEFAULT_COLOR;
        }
    }

    public void VaryEnvironment() {
        GenerateBricks();
        UpdateColor(color);
    }

    public void SetGroundActive(bool active) {
        ground.SetActive(active);
    }

    public void SetCeilingActive(bool active) {
        ceiling.SetActive(active);
    }

    public void SetBricksActive(bool active) {

        GameObject bricks = bricksContainer.transform.GetChild(0).gameObject;
        bricks.SetActive(active);

        if (!active) {
            for (int i = 0; i < bricks.transform.childCount; i++) {
                GameObject brick = bricks.transform.GetChild(i).gameObject;
                Particle.BrickBreak(brick.transform.position, (int)(brick.transform.localScale.x * 10), color);
            }
        }
    }

    public void UpdateColor(Color color) {
        this.color = color;
        frontSR.color = color;
        middleSR.color = color;
        back1SR.color = color;
        back2SR.color = color;
        back3SR.color = color;
        backgroundSR.color = color;
        pipes.SetColor(color);
        groundSR.color = color;

        for (int i = 0; i < brickSRs.Length; i++)
            brickSRs[i].color = color;
    }

    public void GenerateBricks() {

        for (int i = 0; i < bricksContainer.transform.childCount; i++)
            Destroy(bricksContainer.transform.GetChild(i).gameObject);

        GameObject bricks = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Bricks/Layouts " + currEnv + "/layout" + (int)Random.Range(1, 8.999f)), bricksContainer.transform);
        brickSRs = new SpriteRenderer[bricks.transform.childCount];

        for (int i = 0; i < brickSRs.Length; i++)
            brickSRs[i] = bricks.transform.GetChild(i).GetComponent<SpriteRenderer>();
    }

    public void UpdateBackground() {
        back1SR.sprite = Resources.Load<Sprite>("Sprites/Background/back" + currEnv + "-1");
        back2SR.sprite = Resources.Load<Sprite>("Sprites/Background/back" + currEnv + "-2");
        back3SR.sprite = Resources.Load<Sprite>("Sprites/Background/back" + currEnv + "-3");
    }

    public void PumpPipes() {
        pipes.Pump();
    }

}