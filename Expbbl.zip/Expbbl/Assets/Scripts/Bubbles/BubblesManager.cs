using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BubblesManager : MonoBehaviour {

    private const int MAX_BUBBLES = 110;

    private Bubble[] bubbles;
    public int bubbleCount { get; private set; }

    public PlayerStats playerStats;
    public Color color;

    private void Awake() {
        bubbles = new Bubble[MAX_BUBBLES];
        bubbleCount = 0;

        playerStats = GameObject.Find("Player").GetComponent<PlayerStats>();
        color = Color.white;

        for (int i = 0; i < MAX_BUBBLES; i++) {
            bubbles[i] = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Bubble")).GetComponent<Bubble>();
            bubbles[i].gameObject.transform.parent = gameObject.transform;
            bubbles[i].gameObject.SetActive(false);
        }
    }

    private void Update() {

        //int newBubbleCount = 0;

        for (int i = 0; i < MAX_BUBBLES; i++) {
            if (bubbles[i].gameObject.activeSelf) {
                //newBubbleCount++;
                bubbles[i].ManualUpdate();
            }
        }

        //bubbleCount = newBubbleCount;
    }

    public void SpawnGroup(int round) {

        int type = BubbleTypes.SelectRandom(round);
        int level = (int)Mathf.Max(1, (round * 1.35f + 3) / 4);
        int splits = (BubbleTypes.GetSplitCoeff(type) >= 3) ? Bubble.MAX_SPLITS - 1 : Bubble.MAX_SPLITS;
        Spawn(type, BubbleTypes.GetAdjustedLevel(type, level), Pipes.leftSpawnPos, Pipes.leftSpawnVel * Random.Range(0.8f, 1.2f), splits, false, 0);

        type = BubbleTypes.SelectRandom(round);
        level = (int)Mathf.Max(1, (round * 1.25f) / 4 + 1);
        splits = (BubbleTypes.GetSplitCoeff(type) >= 3) ? Bubble.MAX_SPLITS - 1 : Bubble.MAX_SPLITS;
        Spawn(type, BubbleTypes.GetAdjustedLevel(type, level), Pipes.topLeftSpawnPos, Pipes.topLeftSpawnVel * Random.Range(0.8f, 1.2f), splits, false, 0);

        type = BubbleTypes.SelectRandom(round);
        level = (int)Mathf.Max(1, (round * 1.25f + 2) / 4 + 1);
        splits = (BubbleTypes.GetSplitCoeff(type) >= 3) ? Bubble.MAX_SPLITS - 1 : Bubble.MAX_SPLITS;
        Spawn(type, BubbleTypes.GetAdjustedLevel(type, level), Pipes.topRightSpawnPos, Pipes.topRightSpawnVel * Random.Range(0.8f, 1.2f), splits, false, 0);

        type = BubbleTypes.SelectRandom(round);
        level = (int)Mathf.Max(1, (round * 1.35f + 1) / 4);
        splits = (BubbleTypes.GetSplitCoeff(type) >= 3) ? Bubble.MAX_SPLITS - 1 : Bubble.MAX_SPLITS;
        Spawn(type, BubbleTypes.GetAdjustedLevel(type, level), Pipes.rightSpawnPos, Pipes.rightSpawnVel * Random.Range(0.8f, 1.2f), splits, false, 0);
    }

    public void Spawn(int type, int level, Vector2 pos, Vector2 vel, int splitsLeft, bool frozen, float unfreezeTime) {

        for (int i = 0; i < bubbles.Length; i++) {
            if (!bubbles[i].gameObject.activeSelf) {

                bubbles[i].Init(this, i, type, level, pos, vel, splitsLeft, frozen, unfreezeTime);
                bubbles[i].gameObject.SetActive(true);
                
                bubbleCount++;
                return;
            }
        }

        Debug.Log("Bubble object pool full!");
    }

    public void Remove(int index) {
        bubbles[index].gameObject.SetActive(false);
        bubbleCount--;
    }

    public void RemoveAll() {
        for (int i = 0; i < MAX_BUBBLES; i++)
            bubbles[i].gameObject.SetActive(false);
        bubbleCount = 0;
    }

    public bool BubblesCleared() {
        return bubbleCount == 0;
    }

    public void Reset() {
        RemoveAll();
    }
}