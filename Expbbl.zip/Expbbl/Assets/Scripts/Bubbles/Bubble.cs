using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bubble : MonoBehaviour {

    public static float MAX_SPEED = 50;
    public static float DEFAULT_GRAVITY = 0.2f;
    private Vector2 defaultVel;
    private float speedMultiplier;

    public const int MAX_SPLITS = 4;
    private int splitsLeft;

    private const float MAX_SIZE_LEVEL = 15;

    public float eventTime;
    public float eventDelay { get; private set; }

    public float unfreezeTime;
    public bool frozen;

    public int level { get; private set; }
    public int type { get; private set; }
    public int health { get; private set; }
    public int maxHealth { get; private set; }
    public int damage { get; private set; }

    public Rigidbody2D _rigidBody;
    public CircleCollider2D _collider;
    public SpriteRenderer overlaySpriteRenderer;
    public SpriteRenderer innerSpriteRenderer;

    [SerializeField] AudioPlayer _audio;
    [SerializeField] GameObject levelTag;

    private Vector2 initVel;
    private Vector2 saveVel;
    private BubblesManager manager;
    private int index;

    private void Awake() {
        _rigidBody = gameObject.GetComponent<Rigidbody2D>();
        _collider = gameObject.GetComponent<CircleCollider2D>();
        innerSpriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        overlaySpriteRenderer = gameObject.transform.GetChild(0).GetComponent<SpriteRenderer>();
        
        overlaySpriteRenderer.sprite = BubbleTypes.S_OVERLAY;
        initVel = new Vector2(0.0f, 0.0f);
        saveVel = new Vector2(0.0f, 0.0f);
        frozen = false;
        unfreezeTime = 0;
        _rigidBody.gravityScale = DEFAULT_GRAVITY;
    }

    private void OnEnable() {
        _rigidBody.velocity = initVel;
    }

    public void ManualUpdate() {

        levelTag.SetActive(BackgroundScript.showBubbleLevel);

        if (frozen) {
            if (Time.time > unfreezeTime) {
                frozen = false;
                unfreezeTime = 0;
                _rigidBody.velocity = saveVel;
                _rigidBody.gravityScale = DEFAULT_GRAVITY;
            }
        }

        overlaySpriteRenderer.color = manager.color;
        innerSpriteRenderer.color = manager.color;

        BubbleTypes.PassiveEffects(this, manager);

        if (health <= 0) {
            BubbleTypes.PopEffects(this, manager.playerStats);
            Pop();
            return;
        }

        float speed = Util.Mag(_rigidBody.velocity);
        if (speed > MAX_SPEED * speedMultiplier)
            _rigidBody.velocity *= 0.98f * MAX_SPEED * speedMultiplier / speed;
    }

    public void AddHealth(int amount) {

        health += amount;

        if (health < 0) health = 0;
        else if (health > maxHealth) health = maxHealth;
    }

    public void Freeze(float time) {
        saveVel = _rigidBody.velocity;
        _rigidBody.velocity *= 0;
        _rigidBody.gravityScale = 0;
        frozen = true;
        unfreezeTime = Time.time + time;
    }

    public void Pop() {

        Particle.BubblePop(gameObject.transform.position, level);
        manager.playerStats._audio.PopSFX();

        if (level > 1 && splitsLeft > 0) {

            if (frozen) {
                _rigidBody.velocity = saveVel;
            }

            for (int i = 0; i < BubbleTypes.GetSplitCoeff(type); i++) {
                defaultVel.x = _rigidBody.velocity.x + Random.Range(MAX_SPEED, -MAX_SPEED) * speedMultiplier * 0.8f;
                defaultVel.y = _rigidBody.velocity.y + Random.Range(MAX_SPEED, MAX_SPEED * 0.8f) * speedMultiplier * 0.8f * Util.RandomSign();
                manager.Spawn(type, level - 1, gameObject.transform.position, defaultVel, splitsLeft - 1, frozen, unfreezeTime);
            }

        } else if (manager.bubbleCount == 1) {
            GameObject emeralds = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Particles/Emerald"), gameObject.transform.position, Quaternion.identity);
            emeralds.GetComponent<Emeralds>().LateInit(manager.playerStats);
        }

        GameObject coins = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Particles/Coin"), gameObject.transform.position, Quaternion.identity);
        float value = BubbleTypes.GetValue(type, level) / Mathf.Pow(2, MAX_SPLITS - splitsLeft);
        coins.GetComponent<Coins>().LateInit(manager.playerStats, (int) value, _collider.radius * gameObject.transform.localScale.x);

        BubbleTypes.DeathEffects(type, gameObject.transform.position, manager.playerStats.gameObject);

        manager.Remove(index);
    }

    public void Init(BubblesManager manager, int index, int type, int level, Vector2 pos, Vector2 vel, int splitsLeft, bool frozen, float unfreezeTime) {

        this.manager = manager;
        this.index = index;

        this.splitsLeft = splitsLeft;
        InitStats(type, level);

        innerSpriteRenderer.sprite = BubbleTypes.GetSprite(type);

        this.frozen = frozen;
        this.unfreezeTime = unfreezeTime;

        gameObject.transform.position = pos;
        if (frozen) {
            initVel = Vector2.zero;
            saveVel = vel;
            _rigidBody.gravityScale = 0;
        } else initVel = vel;
    }

    private void InitStats(int type, int level) {

        this.level = level;
        this.type = type;

        health = (int)(Mathf.Pow(level, 2) * 10 * BubbleTypes.GetHealthCoeff(type));
        maxHealth = health;
        damage = (int)(Mathf.Pow(level, 2) * 10 * BubbleTypes.GetDamageCoeff(type));

        float size = BubbleTypes.GetSizeCoeff(type);
        if (level < MAX_SIZE_LEVEL) size *= Mathf.Sqrt(level) * 1.2f;
        else size *= Mathf.Sqrt(MAX_SIZE_LEVEL + splitsLeft - MAX_SPLITS) * 1.2f;
        gameObject.transform.localScale = new Vector2(size, size);

        speedMultiplier = BubbleTypes.GetSpeedCoeff(type);
        _rigidBody.sharedMaterial = BubbleTypes.GetMaterial(type);
        _rigidBody.gravityScale = BubbleTypes.GetGravityCoeff(type);
        eventDelay = BubbleTypes.GetEventDelay(type);
        eventTime = Time.time + eventDelay;
    }

    private void OnCollisionEnter2D(Collision2D col) {
        if (gameObject.activeSelf)
            _audio.BounceSFX();
    }
}
