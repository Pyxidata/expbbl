using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BubbleTypes {

    public const int COUPLE = 1; // also indicates the minimum round it can spawn in
    public const int TRIPLET = 3;
    public const int SINGLETON = 4;
    public const int BLOATED = 5;
    public const int DENSE = 11;
    public const int SWIFT = 12;
    public const int THIEF = 14;
    public const int GEMSTONE = 15;
    public const int STEEL = 21;
    public const int PROCREATE = 22;
    public const int SPINNER = 23;
    public const int TITAN = 31;
    public const int ASSASSIN = 33;
    public const int ETHEREAL = 34;
    public const int PARTITIONER = 41;
    public const int EXPLODER = 51;
    public const int DEATH = 61;

    private static int[] SPECIAL_BUBBLES = {
        TRIPLET, SINGLETON, BLOATED, DENSE, SWIFT, THIEF, GEMSTONE, STEEL, 
        PROCREATE, SPINNER, TITAN, ASSASSIN, ETHEREAL, PARTITIONER, EXPLODER, DEATH
    };

    public static Sprite S_OVERLAY = Resources.Load<Sprite>("Sprites/Bubble/overlay");
    public static Sprite S_TRIPLET = Resources.Load<Sprite>("Sprites/Bubble/triplet");
    public static Sprite S_SINGLETON = Resources.Load<Sprite>("Sprites/Bubble/singleton");
    public static Sprite S_BLOATED = Resources.Load<Sprite>("Sprites/Bubble/bloated");
    public static Sprite S_DENSE = Resources.Load<Sprite>("Sprites/Bubble/dense");
    public static Sprite S_SWIFT = Resources.Load<Sprite>("Sprites/Bubble/swift");
    public static Sprite S_THIEF = Resources.Load<Sprite>("Sprites/Bubble/thief");
    public static Sprite S_GEMSTONE = Resources.Load<Sprite>("Sprites/Bubble/gemstone");
    public static Sprite S_STEEL = Resources.Load<Sprite>("Sprites/Bubble/steel");
    public static Sprite S_PROCREATE = Resources.Load<Sprite>("Sprites/Bubble/procreate");
    public static Sprite S_SPINNER = Resources.Load<Sprite>("Sprites/Bubble/spinner");
    public static Sprite S_TITAN = Resources.Load<Sprite>("Sprites/Bubble/titan");
    public static Sprite S_ASSASSIN = Resources.Load<Sprite>("Sprites/Bubble/assassin");
    public static Sprite S_ETHEREAL = Resources.Load<Sprite>("Sprites/Bubble/ethereal");
    public static Sprite S_PARTITIONER = Resources.Load<Sprite>("Sprites/Bubble/partitioner");
    public static Sprite S_EXPLODER = Resources.Load<Sprite>("Sprites/Bubble/exploder");
    public static Sprite S_DEATH = Resources.Load<Sprite>("Sprites/Bubble/death");

    public static int GetAdjustedLevel(int type, int level) {
        return Mathf.Max(1, level - type / 10);
    }

    public static Sprite GetSprite(int type) {
        switch (type) {
            case TRIPLET: return S_TRIPLET; 
            case SINGLETON: return S_SINGLETON; 
            case BLOATED: return S_BLOATED; 
            case DENSE: return S_DENSE; 
            case SWIFT: return S_SWIFT; 
            case THIEF: return S_THIEF; 
            case GEMSTONE: return S_GEMSTONE; 
            case STEEL: return S_STEEL; 
            case PROCREATE: return S_PROCREATE; 
            case SPINNER: return S_SPINNER; 
            case TITAN: return S_TITAN; 
            case ASSASSIN: return S_ASSASSIN; 
            case ETHEREAL: return S_ETHEREAL; 
            case PARTITIONER: return S_PARTITIONER; 
            case EXPLODER: return S_EXPLODER; 
            case DEATH: return S_DEATH; 
            default: return null;
        }
    }

    public static int GetSplitCoeff(int type) {
        switch (type) {
            case TRIPLET: case ETHEREAL:
                return 3;
            case SINGLETON:
                return 1;
            case GEMSTONE:
                return 0;
            default:
                return 2;
        }
    }

    public static float GetSizeCoeff(int type) {
        switch (type) {
            case TITAN:
                return 1.45f;
            case BLOATED:
                return 1.3f;
            case SINGLETON:
                return 1.15f;
            case TRIPLET: case THIEF:
                return 0.85f;
            case SWIFT:
                return 0.7f;
            case DENSE: case ASSASSIN: case GEMSTONE:
                return 0.55f;
            default:
                return 1.0f;
        }
    }

    public static float GetDamageCoeff(int type) {
        switch (type) {
            case PARTITIONER:
                return 0.0f;
            case TRIPLET: case BLOATED:
                return 0.5f;
            case SINGLETON: case DENSE: case ETHEREAL:
                return 1.5f;
            case TITAN: case ASSASSIN:
                return 2.0f;
            case STEEL: case EXPLODER: case DEATH: case GEMSTONE:
                return 2.5f;
            default:
                return 1.0f;
        }
    }

    public static float GetHealthCoeff(int type) {
        switch (type) {
            case TRIPLET: case BLOATED:
                return 0.5f;
            case SINGLETON: case DENSE:
                return 1.5f;
            case TITAN: case DEATH:
                return 2.0f;
            case STEEL: case ETHEREAL:
                return 3.0f;
            case GEMSTONE:
                return 5.0f;
            default:
                return 1.0f;
        }
    }

    public static float GetSpeedCoeff(int type) {
        switch (type) {
            case SWIFT: case ASSASSIN: case STEEL:
                return 1.5f;
            case SPINNER:
                return 2.0f;
            default:
                return 1.0f;
        }
    }

    public static PhysicsMaterial2D GetMaterial(int type) {
        switch (type) {
            case STEEL:
                return Resources.Load<PhysicsMaterial2D>("Materials/SteelBubble");
            case SPINNER:
                return Resources.Load<PhysicsMaterial2D>("Materials/SpinnerBubble");
            default:
                return Resources.Load<PhysicsMaterial2D>("Materials/DefaultBubble");
        }
    }

    public static float GetGravityCoeff(int type) {
        if (type == ETHEREAL) return 0.0f;
        return 0.2f;
    }

    public static float GetBounceCoeff(int type) {
        if (type == STEEL) return 0.0f;
        return 1.0f;
    }

    public static float GetEventDelay(int type) {
        if (type == PROCREATE) return 8.0f;
        return 1.0f;
    }

    public static int GetValue(int type, int level) {
        int value = (int)(Mathf.Pow(((level + (type / 10) * 1.25f) * 12), 2));

        if (GetSplitCoeff(type) == 1) value *= 2;
        if (type == GEMSTONE) value *= 6;
        return value;
    }

    public static void PassiveEffects(Bubble bubble, BubblesManager manager) {
        if (bubble.type == PROCREATE && bubble.eventTime < Time.time) {
            manager.Spawn(SINGLETON, Mathf.Max(1, bubble.level - 3), bubble._rigidBody.position, bubble._rigidBody.velocity * Random.Range(-1.5f, 1.5f), 0, false, 0);
            bubble.eventTime += bubble.eventDelay;
        }
    }

    public static void HitEffects(Bubble bubble, PlayerStats playerStats) {
        if (playerStats.IsAlive()) {
            switch (bubble.type) {
                case THIEF:
                    playerStats.ForceAddCoins(-10 * bubble.damage);
                    // TODO coin lose SFX
                    break;
                case PARTITIONER:
                    playerStats.ForceAddHealth(playerStats.health / -2);
                    // TODO partitioner damage SFX
                    break;
                case DEATH:
                    playerStats.maxHealth -= bubble.damage / 5;
                    if (playerStats.maxHealth < 0)
                        playerStats.maxHealth = 0;
                    // TODO death damage SFX
                    break;
            }
        }
    }

    // Popped by player attacks
    public static void PopEffects(Bubble bubble, PlayerStats playerStats) {
        if (bubble.type == EXPLODER) {
            float dist = Mathf.Max(1, Util.Dist(bubble._rigidBody.position, playerStats.gameObject.transform.position));
            playerStats.AddHealth((int) ((-1.5f / (dist + 1.0f)) * bubble.damage));
            // TODO explosion particle
        }
    }

    // Bubble death; either from being popped or player collision
    public static void DeathEffects(int type, Vector2 pos, GameObject player) {
        if (type == GEMSTONE) {
            GameObject amethysts = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Particles/Amethyst"), pos, Quaternion.identity);
            amethysts.GetComponent<Amethysts>().LateInit(player);
        }
    }

    public static int SelectRandom(int round) {

        int lim = SPECIAL_BUBBLES.Length - 2;
        for (int i = 0; i < SPECIAL_BUBBLES.Length; i++) {
            if (SPECIAL_BUBBLES[i] > round) {
                lim = i - 1;
                break;
            }
        }

        if (lim < 0 || Random.value > SpecialBubbleChance(round)) return COUPLE;

        return SPECIAL_BUBBLES[(int)Random.Range(0, lim + 0.999f)];
    }

    private static float SpecialBubbleChance(int round) {
        return Mathf.Min(0.8f, 0.35f + (int) (round / 10) / 10.0f);
    }
}
