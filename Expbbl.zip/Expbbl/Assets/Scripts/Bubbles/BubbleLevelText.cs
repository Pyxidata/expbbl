using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BubbleLevelText : MonoBehaviour {

    [SerializeField] GameObject bubbleObject;
    [SerializeField] Text text;
    private Bubble bubble;

    private void Awake() {
        bubble = bubbleObject.GetComponent<Bubble>();
    }

    private void Update() {
        text.text = bubble.level + "";
    }
}