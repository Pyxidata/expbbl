using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Empty : Weapon {

    public const int UNLOCK_PRICE = 0;
    public const int BASE_PRICE = 0;

    public const string DEFAULT_NAME = "Empty";

    public Empty() {
        image = Resources.Load<Sprite>("Sprites/UI/button_default");
        smallImage = Resources.Load<Sprite>("Sprites/UI/button_small");

        toggleMode = true;
        name = "Empty";
        sellPrice = 0;
    }

    public override void Use(Vector2 initVel) { }

    public override string GetUpgradeName1() { return "N/A"; }

    public override string GetUpgradeName2() { return "N/A"; }

    public override string GetUpgradeName3() { return "N/A"; }

    public override string GetUpgradeName4() { return "N/A"; }

    public override string GetUpgradeTitle1() { return "N/A"; }

    public override string GetUpgradeTitle2() { return "N/A"; }

    public override string GetUpgradeTitle3() { return "N/A"; }

    public override string GetUpgradeTitle4() { return "N/A"; }

    public override string GetUpgradeSubtitle1() { return "N/A"; }

    public override string GetUpgradeSubtitle2() { return "N/A"; }

    public override string GetUpgradeSubtitle3() { return "N/A"; }

    public override string GetUpgradeSubtitle4() { return "N/A"; }

    public override string GetUpgradeDescription1() { return "N/A"; }

    public override string GetUpgradeDescription2() { return "N/A"; }

    public override string GetUpgradeDescription3() { return "N/A"; }

    public override string GetUpgradeDescription4() { return "N/A"; }

    public override int GetUpgradePrice1() { return 0; }

    public override int GetUpgradePrice2() { return 0; }

    public override int GetUpgradePrice3() { return 0; }

    public override int GetUpgradePrice4() { return 0; }

    public override bool Upgrade1() { return false; }

    public override bool Upgrade2() { return false; }

    public override bool Upgrade3() { return false; }

    public override bool Upgrade4() { return false; }

    public override void ClearParticles() { }
}