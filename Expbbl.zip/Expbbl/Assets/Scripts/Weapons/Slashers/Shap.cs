using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shap : Weapon {

    // Name
    public const string DEFAULT_NAME = "Shap";

    // Prices
    public const int BASE_PRICE = 1000;
    public const int UNLOCK_PRICE = 750;

    // Default attribute values
    private const int DEFAULT_MAGAZINE_CAPACITY = 1;
    private const int DEFAULT_RPM = 600;
    private const int DEFAULT_DAMAGE = 10;
    private const float DEFAULT_RELOAD_TIME = 0.5f;
    private const int DEFAULT_PELLET_COUNT = 1;
    private const float DEFAULT_SPEED = 170.0f;
    private const float Y_OFFSET = 0.0f;

    // Special attribute values
    private const float DEFAULT_SIZE = 4.0f;
    private float size;
    private Transform playerTransform;
    private ParticleSystem.MainModule particleMain;
    private ParticleSystem.ShapeModule particleShape;
    private Animator animator;
    private SpriteRenderer spriteRenderer;

    // Game object & particle system
    private GameObject gameObject;
    private ParticleSystem particleSystem;
    private ParticleSystem.EmitParams emitParams;
    private AttackParticles attackParticles;

    // Upgrade attributes
    private const int MAX_UPGRADE1 = -1;
    private const int MAX_UPGRADE2 = 8;
    private const int MAX_UPGRADE3 = 30;
    private const int MAX_UPGRADE4 = 0;
    private const int DEFAULT_UPGRADE1_INCREMENT = 2;
    private const float DEFAULT_UPGRADE2_INCREMENT = -0.05f;
    private const float DEFAULT_UPGRADE3_INCREMENT = 0.1f;
    private const int DEFAULT_UPGRADE4_INCREMENT = 0;

    public Shap(GameObject player) {

        toggleMode = false;
        muteReload = true;

        image = Resources.Load<Sprite>("Sprites/UI/button_default_shap");
        smallImage = Resources.Load<Sprite>("Sprites/UI/button_small_shap");

        name = DEFAULT_NAME;
        sellPrice = BASE_PRICE;
        basePrice = BASE_PRICE;
        unlockPrice = UNLOCK_PRICE;

        magazineCapacity = DEFAULT_MAGAZINE_CAPACITY;
        rpm = DEFAULT_RPM;
        damage = DEFAULT_DAMAGE;
        reloadTime = DEFAULT_RELOAD_TIME;
        pelletCount = DEFAULT_PELLET_COUNT;

        magazine = DEFAULT_MAGAZINE_CAPACITY;
        fireDelay = 60.0f / rpm;
        nextFireTime = 0.0f;
        reloadEndTime = 0.0f;

        upgrade1Counter = 0;
        upgrade2Counter = 0;
        upgrade3Counter = 0;
        upgrade4Counter = 0;

        gameObject = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Slashers/Shap"), player.transform);
        particleSystem = gameObject.GetComponent<ParticleSystem>();
        attackParticles = gameObject.AddComponent<AttackParticles>();
        attackParticles.damage = damage;
        attackParticles.particleEffects = false;
        emitParams = new ParticleSystem.EmitParams();
        audio = player.GetComponent<AudioPlayer>();

        particleMain = particleSystem.main;
        particleShape = particleSystem.shape;
        animator = gameObject.GetComponent<Animator>();
        spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        playerTransform = player.transform;
        size = DEFAULT_SIZE;
    }

    public override void Use(Vector2 vel) {

        Reload();

        if (magazine > 0 && Time.time > nextFireTime) {
            nextFireTime = Time.time + fireDelay;

            gameObject.transform.position = playerTransform.position + (Vector3)vel * (size * 2.0f);
            gameObject.transform.localScale = Vector3.one * (size / DEFAULT_SIZE);
            particleShape.position = (Vector3)vel * (size * -2.0f / gameObject.transform.localScale.x);

            emitParams.velocity = vel * DEFAULT_SPEED * (size / DEFAULT_SIZE);
            particleSystem.Emit(emitParams, pelletCount);

            if (vel.y != 0) animator.Play("AnimateV");
            else animator.Play("AnimateH");
            spriteRenderer.flipX = vel.x < 0;
            spriteRenderer.flipY = vel.y < 0;

            audio.SlashShapSFX();

            magazine--;
            if (magazine == 0) Reload();
        }
    }

    public override string GetUpgradeName1() { return "Damage"; }

    public override string GetUpgradeName2() { return "Delay"; }

    public override string GetUpgradeName3() { return "Size"; }

    public override string GetUpgradeName4() { return "N/A"; }

    public override string GetUpgradeTitle1() { return damage + ""; }

    public override string GetUpgradeTitle2() { return reloadTime + ""; }

    public override string GetUpgradeTitle3() { return size + ""; }

    public override string GetUpgradeTitle4() { return "N/A"; }

    public override string GetUpgradeSubtitle1() { return upgrade1Counter + ""; }

    public override string GetUpgradeSubtitle2() { return upgrade2Counter + "/" + MAX_UPGRADE2; }

    public override string GetUpgradeSubtitle3() { return upgrade3Counter + "/" + MAX_UPGRADE3; }

    public override string GetUpgradeSubtitle4() { return "N/A"; }

    public override string GetUpgradeDescription1() { return "+" + DEFAULT_UPGRADE1_INCREMENT + " Damage"; }

    public override string GetUpgradeDescription2() { return DEFAULT_UPGRADE2_INCREMENT + " Seconds"; }

    public override string GetUpgradeDescription3() { return "+" + DEFAULT_UPGRADE3_INCREMENT + " Size"; }

    public override string GetUpgradeDescription4() { return "+N/A"; }

    public override int GetUpgradePrice1() { return Mathf.Min(Util.MAX_INT, Util.Simplify(120 * (1 + upgrade1Counter))); }

    public override int GetUpgradePrice2() { return Util.Simplify(200 * (Util.CappedExp(upgrade2Counter, MAX_UPGRADE2 - 1, Util.MAX_INT / 200))); }

    public override int GetUpgradePrice3() { return Util.Simplify(300 * (Util.CappedExp(upgrade3Counter, MAX_UPGRADE3 - 1, Util.MAX_INT / 300))); }

    public override int GetUpgradePrice4() { return 0; }

    public override bool Upgrade1() {
        upgrade1Counter++;
        damage += DEFAULT_UPGRADE1_INCREMENT;
        attackParticles.damage = damage;
        return true;
    }

    public override bool Upgrade2() {
        if (upgrade2Counter == MAX_UPGRADE2) return false;

        upgrade2Counter++;
        reloadTime += DEFAULT_UPGRADE2_INCREMENT;
        reloadTime = Util.Round(reloadTime);
        return true;
    }

    public override bool Upgrade3() {
        if (upgrade3Counter == MAX_UPGRADE3) return false;

        upgrade3Counter++;
        size += DEFAULT_UPGRADE3_INCREMENT;
        size = Util.Round(size);
        return true;
    }

    public override bool Upgrade4() {
        return false;
    }

    public override void ClearParticles() {
        particleSystem.Clear();
    }
}
