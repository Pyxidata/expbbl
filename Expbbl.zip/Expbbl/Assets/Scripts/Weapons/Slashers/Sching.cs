using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sching : Weapon {

    // Name
    public const string DEFAULT_NAME = "Sching";

    // Prices
    public const int BASE_PRICE = 14500;
    public const int UNLOCK_PRICE = 1250;

    // Default attribute values
    private const int DEFAULT_MAGAZINE_CAPACITY = 2;
    private const int DEFAULT_RPM = 600;
    private const int DEFAULT_DAMAGE = 8;
    private const float DEFAULT_RELOAD_TIME = 8.0f;
    private const int DEFAULT_PELLET_COUNT = 1;
    private const float DEFAULT_SPEED = 160.0f;
    private const float Y_OFFSET = 0.15f;

    // Special attribute values
    private PlayerStats playerStats;
    private Rigidbody2D playerBody;
    private float speed;

    // Game object & particle system
    private GameObject gameObject;
    private ParticleSystem particleSystem;
    private ParticleSystem.EmitParams emitParams;
    private AttackParticles attackParticles;

    // Upgrade attributes
    private const int MAX_UPGRADE1 = 25;
    private const int MAX_UPGRADE2 = -1;
    private const int MAX_UPGRADE3 = 10;
    private const int MAX_UPGRADE4 = 12;
    private const int DEFAULT_UPGRADE1_INCREMENT = 2;
    private const int DEFAULT_UPGRADE2_INCREMENT = 1;
    private const float DEFAULT_UPGRADE3_INCREMENT = 30.0f;
    private const float DEFAULT_UPGRADE4_INCREMENT = -0.5f;

    public Sching(GameObject player) {

        toggleMode = false;

        image = Resources.Load<Sprite>("Sprites/UI/button_default_sching");
        smallImage = Resources.Load<Sprite>("Sprites/UI/button_small_sching");

        name = DEFAULT_NAME;
        sellPrice = BASE_PRICE;
        basePrice = BASE_PRICE;
        unlockPrice = UNLOCK_PRICE;

        magazineCapacity = DEFAULT_MAGAZINE_CAPACITY;
        rpm = DEFAULT_RPM;
        damage = DEFAULT_DAMAGE;
        reloadTime = DEFAULT_RELOAD_TIME;
        pelletCount = DEFAULT_PELLET_COUNT;

        magazine = DEFAULT_MAGAZINE_CAPACITY;
        fireDelay = 60.0f / rpm;
        nextFireTime = 0.0f;
        reloadEndTime = 0.0f;

        upgrade1Counter = 0;
        upgrade2Counter = 0;
        upgrade3Counter = 0;
        upgrade4Counter = 0;

        gameObject = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Slashers/Sching"), player.transform);
        particleSystem = gameObject.GetComponent<ParticleSystem>();
        attackParticles = gameObject.AddComponent<AttackParticles>();
        attackParticles.damage = damage;
        attackParticles.particleEffects = false;
        emitParams = new ParticleSystem.EmitParams();
        audio = player.GetComponent<AudioPlayer>();

        playerStats = player.GetComponent<PlayerStats>();
        playerBody = player.GetComponent<Rigidbody2D>();
        speed = DEFAULT_SPEED;
    }

    public override void Use(Vector2 vel) {

        Reload();

        if (magazine > 0 && Time.time > nextFireTime) {
            nextFireTime = Time.time + fireDelay;

            if (vel.y == 0.0f) vel.y += Y_OFFSET;
            else vel.y *= 0.5f;

            playerStats.PhaseThruBubbles(0.2f);
            playerStats.TriggerTrails(0.2f);
            playerBody.velocity += vel * speed;

            particleSystem.Emit(emitParams, pelletCount);

            audio.SlashSchingSFX();

            magazine--;
            if (magazine == 0) Reload();
        }
    }

    public override string GetUpgradeName1() { return "Capacity"; }

    public override string GetUpgradeName2() { return "Damage"; }

    public override string GetUpgradeName3() { return "Speed"; }

    public override string GetUpgradeName4() { return "Reload Time"; }

    public override string GetUpgradeTitle1() { return magazineCapacity + ""; }

    public override string GetUpgradeTitle2() { return damage + ""; }

    public override string GetUpgradeTitle3() { return speed + ""; }

    public override string GetUpgradeTitle4() { return reloadTime + ""; }

    public override string GetUpgradeSubtitle1() { return upgrade1Counter + "/" + MAX_UPGRADE1; }

    public override string GetUpgradeSubtitle2() { return upgrade2Counter + ""; }

    public override string GetUpgradeSubtitle3() { return upgrade3Counter + "/" + MAX_UPGRADE3; }

    public override string GetUpgradeSubtitle4() { return upgrade4Counter + "/" + MAX_UPGRADE4; }

    public override string GetUpgradeDescription1() { return "+" + DEFAULT_UPGRADE1_INCREMENT + " Charges"; }

    public override string GetUpgradeDescription2() { return "+" + DEFAULT_UPGRADE2_INCREMENT + " Damage per Tick"; }

    public override string GetUpgradeDescription3() { return "+" + DEFAULT_UPGRADE3_INCREMENT + " Speed"; }

    public override string GetUpgradeDescription4() { return DEFAULT_UPGRADE4_INCREMENT + " Seconds"; }

    public override int GetUpgradePrice1() { return Util.Simplify(400 * (Util.CappedExp(upgrade1Counter, MAX_UPGRADE1 - 1, Util.MAX_INT / 400))); }

    public override int GetUpgradePrice2() { return Mathf.Min(Util.MAX_INT, Util.Simplify(120 * (1 + upgrade2Counter))); }

    public override int GetUpgradePrice3() { return Util.Simplify(300 * (Util.CappedExp(upgrade3Counter, MAX_UPGRADE3 - 1, Util.MAX_INT / 300))); }

    public override int GetUpgradePrice4() { return Util.Simplify(250 * (Util.CappedExp(upgrade4Counter, MAX_UPGRADE4 - 1, Util.MAX_INT / 250))); }

    public override bool Upgrade1() {
        if (upgrade1Counter == MAX_UPGRADE1) return false;

        upgrade1Counter++;
        magazineCapacity += DEFAULT_UPGRADE1_INCREMENT;
        return true;
    }

    public override bool Upgrade2() {
        upgrade2Counter++;
        damage += DEFAULT_UPGRADE2_INCREMENT;
        attackParticles.damage = damage;
        return true;
    }

    public override bool Upgrade3() {
        if (upgrade3Counter == MAX_UPGRADE3) return false;

        upgrade3Counter++;
        speed += DEFAULT_UPGRADE3_INCREMENT;
        speed = Util.Round(speed);
        return true;
    }

    public override bool Upgrade4() {
        if (upgrade4Counter == MAX_UPGRADE4) return false;

        upgrade4Counter++;
        reloadTime += DEFAULT_UPGRADE4_INCREMENT;
        reloadTime = Util.Round(reloadTime);
        return true;
    }

    public override void ClearParticles() {
        particleSystem.Clear();
    }
}
