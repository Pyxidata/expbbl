using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class SaveData {

    public bool[] availableWeapons { get; private set; }
    public int emeralds { get; private set; }
    public int amethysts { get; private set; }
    public int bestRound { get; private set; }

    public SaveData(bool[] availableWeapons, int emeralds, int amethysts, int bestRound) {
        UpdateData(availableWeapons, emeralds, amethysts, bestRound);
    }

    public void UpdateData(bool[] availableWeapons, int emeralds, int amethysts, int bestRound) {
        this.availableWeapons = availableWeapons;
        this.emeralds = emeralds;
        this.amethysts = amethysts;
        this.bestRound = bestRound;
    }
}