using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Prrrup : Weapon {

    // Name
    public const string DEFAULT_NAME = "Prrrup";

    // Prices
    public const int BASE_PRICE = 3300;
    public const int UNLOCK_PRICE = 5;

    // Default attribute values
    private const int DEFAULT_MAGAZINE_CAPACITY = 1;
    private const int DEFAULT_RPM = 600;
    private const int DEFAULT_DAMAGE = -3;
    private const float DEFAULT_RELOAD_TIME = 60.0f;
    private const int DEFAULT_PELLET_COUNT = 1;
    private const float DEFAULT_SPEED = 0.0f;
    private const float Y_OFFSET = 0.0f;

    // Special attribute values
    private PlayerStats playerStats;
    private const float DEFAULT_HEAL_AMOUNT = 0.1f;
    private float healAmount;

    // Game object & particle system
    private GameObject gameObject;
    private ParticleSystem particleSystem;
    private ParticleSystem.EmitParams emitParams;
    private AttackParticles attackParticles;

    // Upgrade attributes
    private const int MAX_UPGRADE1 = 20;
    private const int MAX_UPGRADE2 = 12;
    private const int MAX_UPGRADE3 = 0;
    private const int MAX_UPGRADE4 = 0;
    private const float DEFAULT_UPGRADE1_INCREMENT = -1.25f;
    private const float DEFAULT_UPGRADE2_INCREMENT = 0.05f;
    private const int DEFAULT_UPGRADE3_INCREMENT = 0;
    private const int DEFAULT_UPGRADE4_INCREMENT = 0;

    public Prrrup(GameObject player) {

        toggleMode = false;

        image = Resources.Load<Sprite>("Sprites/UI/button_default_prrrup");
        smallImage = Resources.Load<Sprite>("Sprites/UI/button_small_prrrup");

        name = DEFAULT_NAME;
        sellPrice = BASE_PRICE;
        basePrice = BASE_PRICE;
        unlockPrice = UNLOCK_PRICE;

        magazineCapacity = DEFAULT_MAGAZINE_CAPACITY;
        rpm = DEFAULT_RPM;
        damage = DEFAULT_DAMAGE;
        reloadTime = DEFAULT_RELOAD_TIME;
        pelletCount = DEFAULT_PELLET_COUNT;

        magazine = DEFAULT_MAGAZINE_CAPACITY;
        fireDelay = 60.0f / rpm;
        nextFireTime = 0.0f;
        reloadEndTime = 0.0f;

        upgrade1Counter = 0;
        upgrade2Counter = 0;
        upgrade3Counter = 0;
        upgrade4Counter = 0;

        gameObject = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Shazams/Prrrup"), player.transform);
        particleSystem = gameObject.GetComponent<ParticleSystem>();
        attackParticles = gameObject.AddComponent<AttackParticles>();
        attackParticles.damage = damage;
        emitParams = new ParticleSystem.EmitParams();
        audio = player.GetComponent<AudioPlayer>();

        playerStats = player.GetComponent<PlayerStats>();
        healAmount = DEFAULT_HEAL_AMOUNT;
    }

    public override void Use(Vector2 vel) {

        Reload();

        if (magazine > 0 && Time.time > nextFireTime) {
            nextFireTime = Time.time + fireDelay;

            particleSystem.Emit(emitParams, pelletCount);
            playerStats.AddHealth((int) (playerStats.maxHealth * healAmount));

            audio.ShazamPrrrupSFX();

            magazine--;
            if (magazine == 0) Reload();
        }
    }

    public override string GetUpgradeName1() { return "Reload Time"; }

    public override string GetUpgradeName2() { return "Heal Amount"; }

    public override string GetUpgradeName3() { return "N/A"; }

    public override string GetUpgradeName4() { return "N/A"; }

    public override string GetUpgradeTitle1() { return reloadTime + ""; }

    public override string GetUpgradeTitle2() { return (int)(healAmount * 100) + ""; }

    public override string GetUpgradeTitle3() { return "N/A"; }

    public override string GetUpgradeTitle4() { return "N/A"; }

    public override string GetUpgradeSubtitle1() { return upgrade1Counter + "/" + MAX_UPGRADE1; }

    public override string GetUpgradeSubtitle2() { return upgrade2Counter + "/" + MAX_UPGRADE2; }

    public override string GetUpgradeSubtitle3() { return "N/A"; }

    public override string GetUpgradeSubtitle4() { return "N/A"; }

    public override string GetUpgradeDescription1() { return DEFAULT_UPGRADE1_INCREMENT + " Seconds"; }

    public override string GetUpgradeDescription2() { return "+" + (int)(DEFAULT_UPGRADE2_INCREMENT * 100) + "% Health"; }

    public override string GetUpgradeDescription3() { return "+N/A"; }

    public override string GetUpgradeDescription4() { return "+N/A"; }

    public override int GetUpgradePrice1() { return Util.Simplify(150 * (Util.CappedExp(upgrade1Counter, MAX_UPGRADE1 - 1, Util.MAX_INT / 150))); }

    public override int GetUpgradePrice2() { return Util.Simplify(700 * (Util.CappedExp(upgrade2Counter, MAX_UPGRADE2 - 1, Util.MAX_INT / 700))); }

    public override int GetUpgradePrice3() { return 0; }

    public override int GetUpgradePrice4() { return 0; }

    public override bool Upgrade1() {
        if (upgrade2Counter == MAX_UPGRADE1) return false;

        upgrade1Counter++;
        reloadTime += DEFAULT_UPGRADE1_INCREMENT;
        reloadTime = Util.Round(reloadTime);
        return true;
    }

    public override bool Upgrade2() {
        if (upgrade2Counter == MAX_UPGRADE2) return false;

        upgrade2Counter++;
        healAmount += DEFAULT_UPGRADE2_INCREMENT;
        healAmount = Util.Round(healAmount);
        return true;
    }

    public override bool Upgrade3() {
        return false;
    }

    public override bool Upgrade4() {
        return false;
    }

    public override void ClearParticles() {
        particleSystem.Clear();
    }
}