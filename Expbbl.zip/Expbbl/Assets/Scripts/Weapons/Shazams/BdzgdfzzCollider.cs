using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BdzgdfzzCollider : MonoBehaviour {

    [SerializeField] CircleCollider2D _collider;

    private float colliderDisableTime;
    private const float DISABLE_BUFFER = 0.1f;

    private void Awake() {
        colliderDisableTime = 0;
    }

    private void Update() {
        if (_collider.enabled) {

            if (colliderDisableTime == 0) {
                colliderDisableTime = Time.time + DISABLE_BUFFER;

            } else if (colliderDisableTime < Time.time) {

                _collider.enabled = false;
                colliderDisableTime = 0;

            }
        }
    }
}