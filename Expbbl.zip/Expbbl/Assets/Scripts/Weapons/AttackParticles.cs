using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackParticles : MonoBehaviour {

    public int damage { get; set; } // Negative damage translates to bubble freezing seconds * -1
    public bool particleEffects { get; set; }
    private ParticleSystem ps;
    private CircleCollider2D _collider;
    private AudioPlayer _audio;
    private List<ParticleCollisionEvent> collisionEvents;


    void Awake() {
        ps = gameObject.GetComponent<ParticleSystem>();
        _audio = gameObject.transform.parent.GetComponent<AudioPlayer>();
        _collider = gameObject.GetComponent<CircleCollider2D>();

        collisionEvents = new List<ParticleCollisionEvent>();
        damage = 0;
        particleEffects = true;
    }

    void OnParticleCollision(GameObject other) {

        int numCollisionEvents = ps.GetCollisionEvents(other, collisionEvents);
        Rigidbody rb = other.GetComponent<Rigidbody>();

        for (int i = 0; i < numCollisionEvents; i++) {

            if (particleEffects && damage > 0)
                Particle.Spark(collisionEvents[i].intersection, damage);

            var bubble = other.GetComponent<Bubble>();
            if (bubble != null)
                bubble.AddHealth(-damage);
            _audio.ShootMissSFX();
        }
    }

    private void OnTriggerEnter2D(Collider2D collider) {

        var bubble = collider.GetComponent<Bubble>();
        if (bubble != null && damage < 0)
            bubble.Freeze(-damage);
    }
}
