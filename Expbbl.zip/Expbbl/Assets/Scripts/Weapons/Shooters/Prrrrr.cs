using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Prrrrr : Weapon {

    // Name
    public const string DEFAULT_NAME = "Prrrrr";

    // Prices
    public const int BASE_PRICE = 10500;
    public const int UNLOCK_PRICE = 500;

    // Default attribute values
    private const int DEFAULT_MAGAZINE_CAPACITY = 45;
    private const int DEFAULT_RPM = 1880;
    private const int DEFAULT_DAMAGE = 4;
    private const float DEFAULT_RELOAD_TIME = 2.5f;
    private const int DEFAULT_PELLET_COUNT = 1;
    private const float DEFAULT_SPEED = 140.0f;
    private const float Y_OFFSET = 0.0f;

    // Game object & particle system
    private GameObject gameObject;
    private ParticleSystem particleSystem;
    private ParticleSystem.EmitParams emitParams;
    private AttackParticles attackParticles;

    // Upgrade attributes
    private const int MAX_UPGRADE1 = -1;
    private const int MAX_UPGRADE2 = 10;
    private const int MAX_UPGRADE3 = 0;
    private const int MAX_UPGRADE4 = 0;
    private const int DEFAULT_UPGRADE1_INCREMENT = 2;
    private const float DEFAULT_UPGRADE2_INCREMENT = -0.15f;
    private const int DEFAULT_UPGRADE3_INCREMENT = 0;
    private const int DEFAULT_UPGRADE4_INCREMENT = 0;

    public Prrrrr(GameObject player) {

        toggleMode = true;

        image = Resources.Load<Sprite>("Sprites/UI/button_default_prrrrr");
        smallImage = Resources.Load<Sprite>("Sprites/UI/button_small_prrrrr");

        name = DEFAULT_NAME;
        sellPrice = BASE_PRICE;
        basePrice = BASE_PRICE;
        unlockPrice = UNLOCK_PRICE;

        magazineCapacity = DEFAULT_MAGAZINE_CAPACITY;
        rpm = DEFAULT_RPM;
        damage = DEFAULT_DAMAGE;
        reloadTime = DEFAULT_RELOAD_TIME;
        pelletCount = DEFAULT_PELLET_COUNT;

        magazine = DEFAULT_MAGAZINE_CAPACITY;
        fireDelay = 60.0f / rpm;
        nextFireTime = 0.0f;
        reloadEndTime = 0.0f;

        upgrade1Counter = 0;
        upgrade2Counter = 0;
        upgrade3Counter = 0;
        upgrade4Counter = 0;

        gameObject = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Shooters/Prrrrr"), player.transform);
        particleSystem = gameObject.GetComponent<ParticleSystem>();
        attackParticles = gameObject.AddComponent<AttackParticles>();
        attackParticles.damage = damage;
        emitParams = new ParticleSystem.EmitParams();
        audio = player.GetComponent<AudioPlayer>();
    }

    public override void Use(Vector2 vel) {

        Reload();

        if (magazine > 0 && Time.time > nextFireTime) {
            nextFireTime = Time.time + fireDelay;

            emitParams.velocity = vel * DEFAULT_SPEED;
            particleSystem.Emit(emitParams, pelletCount);

            audio.ShootPrrrrrSFX();

            magazine--;
            if (magazine == 0) Reload();
        }
    }

    public override string GetUpgradeName1() { return "Damage"; }

    public override string GetUpgradeName2() { return "Reload Time"; }

    public override string GetUpgradeName3() { return "N/A"; }

    public override string GetUpgradeName4() { return "N/A"; }

    public override string GetUpgradeTitle1() { return damage + ""; }

    public override string GetUpgradeTitle2() { return reloadTime + ""; }

    public override string GetUpgradeTitle3() { return "N/A"; }

    public override string GetUpgradeTitle4() { return "N/A"; }

    public override string GetUpgradeSubtitle1() { return upgrade1Counter + ""; }

    public override string GetUpgradeSubtitle2() { return upgrade2Counter + ""; }

    public override string GetUpgradeSubtitle3() { return "N/A"; }

    public override string GetUpgradeSubtitle4() { return "N/A"; }

    public override string GetUpgradeDescription1() { return "+" + DEFAULT_UPGRADE1_INCREMENT + " Damage"; }

    public override string GetUpgradeDescription2() { return DEFAULT_UPGRADE2_INCREMENT + " Seconds"; }

    public override string GetUpgradeDescription3() { return "+N/A"; }

    public override string GetUpgradeDescription4() { return "+N/A"; }

    public override int GetUpgradePrice1() { return Mathf.Min(Util.MAX_INT, Util.Simplify(140 * (1 + upgrade1Counter))); }

    public override int GetUpgradePrice2() { return Util.Simplify(250 * (Util.CappedExp(upgrade2Counter, MAX_UPGRADE2 - 1, Util.MAX_INT / 250))); }

    public override int GetUpgradePrice3() { return 0; }

    public override int GetUpgradePrice4() { return 0; }

    public override bool Upgrade1() {
        upgrade1Counter++;
        damage += DEFAULT_UPGRADE1_INCREMENT;
        attackParticles.damage = damage;
        return true;
    }

    public override bool Upgrade2() {
        if (upgrade2Counter == MAX_UPGRADE2) return false;

        upgrade2Counter++;
        reloadTime += DEFAULT_UPGRADE2_INCREMENT;
        reloadTime = Util.Round(reloadTime);
        return true;
    }

    public override bool Upgrade3() {
        return false;
    }

    public override bool Upgrade4() {
        return false;
    }

    public override void ClearParticles() {
        particleSystem.Clear();
    }
}
