using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BamBam : Weapon {

    // Name
    public const string DEFAULT_NAME = "Bam Bam";

    // Prices
    public const int BASE_PRICE = 3500;
    public const int UNLOCK_PRICE = 500;

    // Default attribute values
    private const int DEFAULT_MAGAZINE_CAPACITY = 5;
    private const int DEFAULT_RPM = 60;
    private const int DEFAULT_DAMAGE = 20;
    private const float DEFAULT_RELOAD_TIME = 2.5f;
    private const int DEFAULT_PELLET_COUNT = 3;
    private const float DEFAULT_SPEED = 200.0f;
    private const float Y_OFFSET = 0.0f;

    // Game object & particle system
    private GameObject gameObject;
    private ParticleSystem particleSystem;
    private ParticleSystem.EmitParams emitParams;
    private AttackParticles attackParticles;

    // Upgrade attributes
    private const int MAX_UPGRADE1 = -1;
    private const int MAX_UPGRADE2 = -1;
    private const int MAX_UPGRADE3 = 13;
    private const int MAX_UPGRADE4 = 40;
    private const int DEFAULT_UPGRADE1_INCREMENT = 2;
    private const int DEFAULT_UPGRADE2_INCREMENT = 4;
    private const int DEFAULT_UPGRADE3_INCREMENT = 1;
    private const int DEFAULT_UPGRADE4_INCREMENT = 30;

    public BamBam(GameObject player) {

        toggleMode = true;

        image = Resources.Load<Sprite>("Sprites/UI/button_default_bambam");
        smallImage = Resources.Load<Sprite>("Sprites/UI/button_small_bambam");

        name = DEFAULT_NAME;
        sellPrice = BASE_PRICE;
        basePrice = BASE_PRICE;
        unlockPrice = UNLOCK_PRICE;

        magazineCapacity = DEFAULT_MAGAZINE_CAPACITY;
        rpm = DEFAULT_RPM;
        damage = DEFAULT_DAMAGE;
        reloadTime = DEFAULT_RELOAD_TIME;
        pelletCount = DEFAULT_PELLET_COUNT;

        magazine = DEFAULT_MAGAZINE_CAPACITY;
        fireDelay = 60.0f / rpm;
        nextFireTime = 0.0f;
        reloadEndTime = 0.0f;

        upgrade1Counter = 0;
        upgrade2Counter = 0;
        upgrade3Counter = 0;
        upgrade4Counter = 0;

        gameObject = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Shooters/BamBam"), player.transform);
        particleSystem = gameObject.GetComponent<ParticleSystem>();
        attackParticles = gameObject.AddComponent<AttackParticles>();
        attackParticles.damage = damage;
        emitParams = new ParticleSystem.EmitParams();
        audio = player.GetComponent<AudioPlayer>();
    }

    public override void Use(Vector2 vel) {

        Reload();

        if (magazine > 0 && Time.time > nextFireTime) {
            nextFireTime = Time.time + fireDelay;

            Vector3 addVec = new Vector3(vel.x, vel.y, 0);

            for (int i = 0; i < pelletCount; i++) {
                emitParams.position = gameObject.transform.position + addVec * i * 0.7f;
                emitParams.velocity = vel * DEFAULT_SPEED;
                particleSystem.Emit(emitParams, 1);
            }

            audio.ShootBamBamSFX();

            magazine--;
            if (magazine == 0) Reload();
        }
    }

    public override string GetUpgradeName1() { return "Capacity"; }

    public override string GetUpgradeName2() { return "Damage"; }

    public override string GetUpgradeName3() { return "Pellets"; }

    public override string GetUpgradeName4() { return "Fire Rate"; }

    public override string GetUpgradeTitle1() { return magazineCapacity + ""; }

    public override string GetUpgradeTitle2() { return damage + ""; }

    public override string GetUpgradeTitle3() { return pelletCount + ""; }

    public override string GetUpgradeTitle4() { return rpm + ""; }

    public override string GetUpgradeSubtitle1() { return upgrade1Counter + ""; }

    public override string GetUpgradeSubtitle2() { return upgrade2Counter + ""; }

    public override string GetUpgradeSubtitle3() { return upgrade3Counter + "/" + MAX_UPGRADE3; }

    public override string GetUpgradeSubtitle4() { return upgrade4Counter + "/" + MAX_UPGRADE4; }

    public override string GetUpgradeDescription1() { return "+" + DEFAULT_UPGRADE1_INCREMENT + " Pellets"; }

    public override string GetUpgradeDescription2() { return "+" + DEFAULT_UPGRADE2_INCREMENT + " Damage"; }

    public override string GetUpgradeDescription3() { return "+" + DEFAULT_UPGRADE3_INCREMENT + " Pellets"; }

    public override string GetUpgradeDescription4() { return "+" + DEFAULT_UPGRADE4_INCREMENT + " RPM"; }

    public override int GetUpgradePrice1() { return Mathf.Min(Util.MAX_INT, Util.Simplify(100 * (1 + upgrade1Counter))); }

    public override int GetUpgradePrice2() { return Mathf.Min(Util.MAX_INT, Util.Simplify(150 * (1 + upgrade2Counter))); }

    public override int GetUpgradePrice3() { return Util.Simplify(400 * (Util.CappedExp(upgrade3Counter, MAX_UPGRADE3 - 1, Util.MAX_INT / 400))); }

    public override int GetUpgradePrice4() { return Util.Simplify(250 * (Util.CappedExp(upgrade4Counter, MAX_UPGRADE4 - 1, Util.MAX_INT / 250))); }

    public override bool Upgrade1() {
        upgrade1Counter++;
        magazineCapacity += DEFAULT_UPGRADE1_INCREMENT;
        return true;
    }

    public override bool Upgrade2() {
        upgrade2Counter++;
        damage += DEFAULT_UPGRADE2_INCREMENT;
        attackParticles.damage = damage;
        return true;
    }

    public override bool Upgrade3() {
        if (upgrade3Counter == MAX_UPGRADE3) return false;

        upgrade3Counter++;
        pelletCount += DEFAULT_UPGRADE3_INCREMENT;
        return true;
    }

    public override bool Upgrade4() {
        if (upgrade4Counter == MAX_UPGRADE4) return false;

        upgrade4Counter++;
        rpm += DEFAULT_UPGRADE4_INCREMENT;
        return true;
    }

    public override void ClearParticles() {
        particleSystem.Clear();
    }
}
