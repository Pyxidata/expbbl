using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PokPok : Weapon {

    // Name
    public const string DEFAULT_NAME = "Pok Pok";

    // Prices
    public const int BASE_PRICE = 5000;
    public const int UNLOCK_PRICE = 250;

    // Default attribute values
    private const int DEFAULT_MAGAZINE_CAPACITY = 60;
    private const int DEFAULT_RPM = 120;
    private const int DEFAULT_DAMAGE = 30;
    private const float DEFAULT_RELOAD_TIME = 10.0f;
    private const int DEFAULT_PELLET_COUNT = 1;
    private const float DEFAULT_SPEED = 85.0f;
    private const float Y_OFFSET = 0.2f;

    // Special attribute values
    private const float DEFAULT_RECOIL = 20.0f;
    private float recoil;
    private const float DEFAULT_KNOCKBACK = 1200.0f;
    private float knockback;
    private Rigidbody2D playerBody;
    private ParticleSystem.CollisionModule particleCollision;

    // Game object & particle system
    private GameObject gameObject;
    private ParticleSystem particleSystem;
    private ParticleSystem.EmitParams emitParams;
    private AttackParticles attackParticles;

    // Upgrade attributes
    private const int MAX_UPGRADE1 = -1;
    private const int MAX_UPGRADE2 = 25;
    private const int MAX_UPGRADE3 = 40;
    private const int MAX_UPGRADE4 = 10;
    private const int DEFAULT_UPGRADE1_INCREMENT = 5;
    private const int DEFAULT_UPGRADE2_INCREMENT = 20;
    private const float DEFAULT_UPGRADE3_INCREMENT = 1600.0f;
    private const float DEFAULT_UPGRADE4_INCREMENT = 4.0f;


    public PokPok(GameObject player) {

        toggleMode = true;

        image = Resources.Load<Sprite>("Sprites/UI/button_default_pokpok");
        smallImage = Resources.Load<Sprite>("Sprites/UI/button_small_pokpok");

        name = DEFAULT_NAME;
        sellPrice = BASE_PRICE;
        basePrice = BASE_PRICE;
        unlockPrice = UNLOCK_PRICE;

        magazineCapacity = DEFAULT_MAGAZINE_CAPACITY;
        rpm = DEFAULT_RPM;
        damage = DEFAULT_DAMAGE;
        reloadTime = DEFAULT_RELOAD_TIME;
        pelletCount = DEFAULT_PELLET_COUNT;

        magazine = DEFAULT_MAGAZINE_CAPACITY;
        fireDelay = 60.0f / rpm;
        nextFireTime = 0.0f;
        reloadEndTime = 0.0f;

        upgrade1Counter = 0;
        upgrade2Counter = 0;
        upgrade3Counter = 0;
        upgrade4Counter = 0;

        gameObject = GameObject.Instantiate(Resources.Load<GameObject>("Prefabs/Shooters/PokPok"), player.transform);
        particleSystem = gameObject.GetComponent<ParticleSystem>();
        attackParticles = gameObject.AddComponent<AttackParticles>();
        attackParticles.damage = damage;
        emitParams = new ParticleSystem.EmitParams();
        audio = player.GetComponent<AudioPlayer>();

        recoil = DEFAULT_RECOIL;
        playerBody = player.GetComponent<Rigidbody2D>();
        particleCollision = particleSystem.collision;
        knockback = DEFAULT_KNOCKBACK;
    }

    public override void Use(Vector2 vel) {

        Reload();

        if (magazine > 0 && Time.time > nextFireTime) {
            nextFireTime = Time.time + fireDelay;

            if (vel.y == 0.0f) vel.y += Y_OFFSET;
            emitParams.velocity = vel * DEFAULT_SPEED;
            playerBody.velocity -= vel * recoil;

            particleCollision.colliderForce = knockback;

            particleSystem.Emit(emitParams, pelletCount);

            audio.ShootPokPokSFX();

            magazine--;
            if (magazine == 0) Reload();
        }
    }

    public override string GetUpgradeName1() { return "Damage"; }

    public override string GetUpgradeName2() { return "Fire Rate"; }

    public override string GetUpgradeName3() { return "Knockback"; }

    public override string GetUpgradeName4() { return "Recoil"; }

    public override string GetUpgradeTitle1() { return damage + ""; }

    public override string GetUpgradeTitle2() { return rpm + ""; }

    public override string GetUpgradeTitle3() { return knockback + ""; }

    public override string GetUpgradeTitle4() { return recoil + ""; }

    public override string GetUpgradeSubtitle1() { return upgrade1Counter + ""; }

    public override string GetUpgradeSubtitle2() { return upgrade2Counter + "/" + MAX_UPGRADE2; }

    public override string GetUpgradeSubtitle3() { return upgrade3Counter + "/" + MAX_UPGRADE3; }

    public override string GetUpgradeSubtitle4() { return upgrade4Counter + "/" + MAX_UPGRADE4; }

    public override string GetUpgradeDescription1() { return "+" + DEFAULT_UPGRADE1_INCREMENT + " Damage"; }

    public override string GetUpgradeDescription2() { return "+" + DEFAULT_UPGRADE2_INCREMENT + " RPM"; }

    public override string GetUpgradeDescription3() { return "+" + DEFAULT_UPGRADE3_INCREMENT + " Knockback"; }

    public override string GetUpgradeDescription4() { return "+" + DEFAULT_UPGRADE4_INCREMENT + " Recoil"; }

    public override int GetUpgradePrice1() { return Mathf.Min(Util.MAX_INT, Util.Simplify(170 * (1 + upgrade1Counter))); }

    public override int GetUpgradePrice2() { return Util.Simplify(150 * (Util.CappedExp(upgrade2Counter, MAX_UPGRADE2 - 1, Util.MAX_INT / 150))); }

    public override int GetUpgradePrice3() { return Util.Simplify(100 * (Util.CappedExp(upgrade3Counter, MAX_UPGRADE3 - 1, Util.MAX_INT / 100))); }

    public override int GetUpgradePrice4() { return Util.Simplify(100 * (Util.CappedExp(upgrade4Counter, MAX_UPGRADE4 - 1, Util.MAX_INT / 100))); }

    public override bool Upgrade1() {
        upgrade1Counter++;
        damage += DEFAULT_UPGRADE1_INCREMENT;
        attackParticles.damage = damage;
        return true;
    }

    public override bool Upgrade2() {
        if (upgrade2Counter == MAX_UPGRADE2) return false;

        upgrade2Counter++;
        rpm += DEFAULT_UPGRADE2_INCREMENT;
        return true;
    }

    public override bool Upgrade3() {
        if (upgrade3Counter == MAX_UPGRADE3) return false;

        upgrade3Counter++;
        knockback += DEFAULT_UPGRADE3_INCREMENT;
        knockback = Util.Round(knockback);
        return true;
    }

    public override bool Upgrade4() {
        if (upgrade4Counter == MAX_UPGRADE4) return false;

        upgrade4Counter++;
        recoil += DEFAULT_UPGRADE4_INCREMENT;
        recoil = Util.Round(recoil);
        return true;
    }

    public override void ClearParticles() {
        particleSystem.Clear();
    }
}