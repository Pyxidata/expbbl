using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Weapon {

    // Name
    public string name { get; protected set; }

    // Image
    public Sprite image { get; protected set; }
    public Sprite smallImage { get; protected set; }

    // Price
    public int basePrice { get; set; }
    public int unlockPrice { get; set; }
    public int sellPrice { get; set; }

    // Upgradable attributes
    protected int magazineCapacity;
    protected int rpm;
    protected int damage;
    protected float reloadTime;
    protected int pelletCount;

    // Dynamic attributes
    protected int magazine;
    protected float fireDelay;
    protected float nextFireTime;
    protected float reloadEndTime;

    // Upgrade counters
    protected int upgrade1Counter;
    protected int upgrade2Counter;
    protected int upgrade3Counter;
    protected int upgrade4Counter;

    // Attack mode
    public bool toggleMode;

    // Audio
    protected AudioPlayer audio;
    protected bool muteReload;

    public void Reload() {
        if (Time.time > reloadEndTime) {
            if (magazine == 0) {
                reloadEndTime = Time.time + reloadTime;
                magazine = -1; // means "reloading"
                
                if (!muteReload) audio.ReloadStartSFX();

            } else if (magazine == -1) {
                magazine = magazineCapacity;
                if (!muteReload) audio.ReloadFinishSFX();
            }
        }
    }

    public string GetMagazineLabel() {

        if (magazine == -1) {
            if (Time.time > reloadEndTime) {
                magazine = magazineCapacity;
                if (!muteReload) audio.ReloadFinishSFX();
            } else return "Reloading - " + (int)(100 - (reloadEndTime - Time.time) / reloadTime * 100) + "%";
        }

        string displayMag = magazine + "";
        if (magazine > 1000000)
            displayMag = (magazine / 1000000) + "M";
        else if (magazine > 1000)
            displayMag = (magazine / 1000) + "K";

        string displayMagCap = magazineCapacity + "";
        if (magazineCapacity > 1000000)
            displayMagCap = (magazineCapacity / 1000000) + "M";
        else if (magazineCapacity > 1000)
            displayMagCap = (magazineCapacity / 1000) + "K";

        return displayMag + " / " + displayMagCap;
    }

    public void ForceReload() {

        if (magazine != -1 && magazine != magazineCapacity) {
            reloadEndTime = Time.time + reloadTime;
            magazine = -1; // means "reloading"
            if (!muteReload) audio.ReloadStartSFX();
        }
    }

    public void ForceReloadInstantly() {
        reloadEndTime = 0;
        magazine = magazineCapacity;
    }

    public abstract void ClearParticles();

    public abstract void Use(Vector2 vel);

    public abstract string GetUpgradeName1();

    public abstract string GetUpgradeName2();

    public abstract string GetUpgradeName3();

    public abstract string GetUpgradeName4();

    public abstract string GetUpgradeTitle1();

    public abstract string GetUpgradeTitle2();

    public abstract string GetUpgradeTitle3();

    public abstract string GetUpgradeTitle4();

    public abstract string GetUpgradeSubtitle1();

    public abstract string GetUpgradeSubtitle2();

    public abstract string GetUpgradeSubtitle3();

    public abstract string GetUpgradeSubtitle4();

    public abstract string GetUpgradeDescription1();

    public abstract string GetUpgradeDescription2();

    public abstract string GetUpgradeDescription3();

    public abstract string GetUpgradeDescription4();

    public abstract int GetUpgradePrice1();

    public abstract int GetUpgradePrice2();

    public abstract int GetUpgradePrice3();

    public abstract int GetUpgradePrice4();

    public abstract bool Upgrade1();

    public abstract bool Upgrade2();

    public abstract bool Upgrade3();

    public abstract bool Upgrade4();
}
