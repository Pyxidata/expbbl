using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponsHandler : MonoBehaviour {

    public static bool[] available { get; set; }

    private static Sprite blankButtonSprite;
    private static Sprite[] sprites;
    private static Sprite[] upgradeSprites;

    void Start() {
        available = BackgroundScript.availableWeapons;

        blankButtonSprite = Resources.Load<Sprite>("Sprites/UI/button_default");

        sprites = new Sprite[30];
        sprites[0] = Resources.Load<Sprite>("Sprites/UI/button_small_pewpew");
        sprites[1] = Resources.Load<Sprite>("Sprites/UI/button_small_powpow");
        sprites[2] = Resources.Load<Sprite>("Sprites/UI/button_small_splat");
        sprites[3] = Resources.Load<Sprite>("Sprites/UI/button_small_pttttt");
        sprites[4] = Resources.Load<Sprite>("Sprites/UI/button_small_pokpok");
        sprites[5] = Resources.Load<Sprite>("Sprites/UI/button_small_bambam");
        sprites[6] = Resources.Load<Sprite>("Sprites/UI/button_small_brrrrr");
        sprites[7] = Resources.Load<Sprite>("Sprites/UI/button_small_prrrrr");
        sprites[8] = Resources.Load<Sprite>("Sprites/UI/button_small_gluk");
        sprites[9] = Resources.Load<Sprite>("Sprites/UI/button_small");
        sprites[10] = Resources.Load<Sprite>("Sprites/UI/button_small_swoosh");
        sprites[11] = Resources.Load<Sprite>("Sprites/UI/button_small_shap");
        sprites[12] = Resources.Load<Sprite>("Sprites/UI/button_small_chching");
        sprites[13] = Resources.Load<Sprite>("Sprites/UI/button_small_shing");
        sprites[14] = Resources.Load<Sprite>("Sprites/UI/button_small_sching");
        for (int i = 15; i < 20; i++) sprites[i] = Resources.Load<Sprite>("Sprites/UI/button_small");
        sprites[20] = Resources.Load<Sprite>("Sprites/UI/button_small_prrrup");
        sprites[21] = Resources.Load<Sprite>("Sprites/UI/button_small_zwoom");
        sprites[22] = Resources.Load<Sprite>("Sprites/UI/button_small_bdzgdfzz");
        for (int i = 23; i < 30; i++) sprites[i] = Resources.Load<Sprite>("Sprites/UI/button_small");

        upgradeSprites = new Sprite[14];
        upgradeSprites[0] = Resources.Load<Sprite>("Sprites/UI/button_default_reload_speed");
        upgradeSprites[1] = Resources.Load<Sprite>("Sprites/UI/button_default_firerate");
        upgradeSprites[2] = Resources.Load<Sprite>("Sprites/UI/button_default_damage");
        upgradeSprites[3] = Resources.Load<Sprite>("Sprites/UI/button_default_duration");
        upgradeSprites[4] = Resources.Load<Sprite>("Sprites/UI/button_default_bounces");
        upgradeSprites[5] = Resources.Load<Sprite>("Sprites/UI/button_default_knockback");
        upgradeSprites[6] = Resources.Load<Sprite>("Sprites/UI/button_default_recoil");
        upgradeSprites[7] = Resources.Load<Sprite>("Sprites/UI/button_default_speed");
        upgradeSprites[8] = Resources.Load<Sprite>("Sprites/UI/button_default_size");
        upgradeSprites[9] = Resources.Load<Sprite>("Sprites/UI/button_default_pellets");
        upgradeSprites[10] = Resources.Load<Sprite>("Sprites/UI/button_default_targets");
        upgradeSprites[11] = Resources.Load<Sprite>("Sprites/UI/button_default_spread");
        upgradeSprites[12] = Resources.Load<Sprite>("Sprites/UI/button_default_magazine_size");
        upgradeSprites[13] = Resources.Load<Sprite>("Sprites/UI/button_default_heal");
    }

    public static int GetUnlockPrice(int type, int displaySlot) {

        switch (type) {

            case 0: // Shooters
                switch (displaySlot) {
                    case 0: return PewPew.UNLOCK_PRICE;
                    case 1: return PowPow.UNLOCK_PRICE;
                    case 2: return Splat.UNLOCK_PRICE;
                    case 3: return Pttttt.UNLOCK_PRICE;
                    case 4: return PokPok.UNLOCK_PRICE;
                    case 5: return BamBam.UNLOCK_PRICE;
                    case 6: return Brrrrr.UNLOCK_PRICE;
                    case 7: return Prrrrr.UNLOCK_PRICE;
                    case 8: return Gluk.UNLOCK_PRICE;
                }
                break;

            case 1: // Slashers
                switch (displaySlot) {
                    case 0: return Swoosh.UNLOCK_PRICE;
                    case 1: return Shap.UNLOCK_PRICE;
                    case 2: return Chching.UNLOCK_PRICE;
                    case 3: return Shing.UNLOCK_PRICE;
                    case 4: return Sching.UNLOCK_PRICE;
                    case 5: return -1;
                    case 6: return -1;
                    case 7: return -1;
                    case 8: return -1;
                }
                break;

            case 2: // Shazams
                switch (displaySlot) {
                    case 0: return Prrrup.UNLOCK_PRICE;
                    case 1: return Zwoom.UNLOCK_PRICE;
                    case 2: return Bdzgdfzz.UNLOCK_PRICE;
                    case 3: return -1;
                    case 4: return -1;
                    case 5: return -1;
                    case 6: return -1;
                    case 7: return -1;
                    case 8: return -1;
                }
                break;
        }
        return -1;
    }

    public static int GetBasePrice(int type, int displaySlot) {

        switch (type) {

            case 0: // Shooters
                switch (displaySlot) {
                    case 0: return PewPew.BASE_PRICE;
                    case 1: return PowPow.BASE_PRICE;
                    case 2: return Splat.BASE_PRICE;
                    case 3: return Pttttt.BASE_PRICE;
                    case 4: return PokPok.BASE_PRICE;
                    case 5: return BamBam.BASE_PRICE;
                    case 6: return Brrrrr.BASE_PRICE;
                    case 7: return Prrrrr.BASE_PRICE;
                    case 8: return Gluk.BASE_PRICE;
                }
                break;

            case 1: // Slashers
                switch (displaySlot) {
                    case 0: return Swoosh.BASE_PRICE;
                    case 1: return Shap.BASE_PRICE;
                    case 2: return Chching.BASE_PRICE;
                    case 3: return Shing.BASE_PRICE;
                    case 4: return Sching.BASE_PRICE;
                    case 5: return -1;
                    case 6: return -1;
                    case 7: return -1;
                    case 8: return -1;
                }
                break;

            case 2: // Shazams
                switch (displaySlot) {
                    case 0: return Prrrup.BASE_PRICE;
                    case 1: return Zwoom.BASE_PRICE;
                    case 2: return Bdzgdfzz.BASE_PRICE;
                    case 3: return -1;
                    case 4: return -1;
                    case 5: return -1;
                    case 6: return -1;
                    case 7: return -1;
                    case 8: return -1;
                }
                break;
        }

        return -1;
    }

    public static Weapon GetNew(int type, int displaySlot, GameObject player) {

        switch (type) {

            case 0: // Shooters
                switch (displaySlot) {
                    case 0: return new PewPew(player);
                    case 1: return new PowPow(player);
                    case 2: return new Splat(player);
                    case 3: return new Pttttt(player);
                    case 4: return new PokPok(player);
                    case 5: return new BamBam(player);
                    case 6: return new Brrrrr(player);
                    case 7: return new Prrrrr(player);
                    case 8: return new Gluk(player);
                }
                break;

            case 1: // Slashers
                switch (displaySlot) {
                    case 0: return new Swoosh(player);
                    case 1: return new Shap(player);
                    case 2: return new Chching(player);
                    case 3: return new Shing(player);
                    case 4: return new Sching(player);
                    case 5: return null;
                    case 6: return null;
                    case 7: return null;
                    case 8: return null;
                }
                break;

            case 2: // Shazams
                switch (displaySlot) {
                    case 0: return new Prrrup(player);
                    case 1: return new Zwoom(player);
                    case 2: return new Bdzgdfzz(player);
                    case 3: return null;
                    case 4: return null;
                    case 5: return null;
                    case 6: return null;
                    case 7: return null;
                    case 8: return null;
                }
                break;
        }

        return null;
    }

    public static string GetDisplayName(int type, int displaySlot) {

        switch (type) {

            case 0: // Shooters
                switch (displaySlot) {
                    case 0: return available[0] ? PewPew.DEFAULT_NAME : "Locked";
                    case 1: return available[1] ? PowPow.DEFAULT_NAME : "Locked";
                    case 2: return available[2] ? Splat.DEFAULT_NAME : "Locked";
                    case 3: return available[3] ? Pttttt.DEFAULT_NAME : "Locked";
                    case 4: return available[4] ? PokPok.DEFAULT_NAME : "Locked";
                    case 5: return available[5] ? BamBam.DEFAULT_NAME : "Locked";
                    case 6: return available[6] ? Brrrrr.DEFAULT_NAME : "Locked";
                    case 7: return available[7] ? Prrrrr.DEFAULT_NAME : "Locked";
                    case 8: return available[8] ? Gluk.DEFAULT_NAME : "Locked";
                } break;

            case 1: // Slashers
                switch (displaySlot) {
                    case 0: return available[10] ? Swoosh.DEFAULT_NAME : "Locked";
                    case 1: return available[11] ? Shap.DEFAULT_NAME : "Locked";
                    case 2: return available[12] ? Chching.DEFAULT_NAME : "Locked";
                    case 3: return available[13] ? Shing.DEFAULT_NAME : "Locked";
                    case 4: return available[14] ? Sching.DEFAULT_NAME : "Locked";
                    case 5: return "???";
                    case 6: return "???";
                    case 7: return "???";
                    case 8: return "???";
                } break;

            case 2: // Shazams
                switch (displaySlot) {
                    case 0: return available[20] ? Prrrup.DEFAULT_NAME : "Locked";
                    case 1: return available[21] ? Zwoom.DEFAULT_NAME : "Locked";
                    case 2: return available[22] ? Bdzgdfzz.DEFAULT_NAME : "Locked";
                    case 3: return "???";
                    case 4: return "???";
                    case 5: return "???";
                    case 6: return "???";
                    case 7: return "???";
                    case 8: return "???";
                } break;
        }

        return "Error";
    }

    public static Sprite GetSmallImage(int type, int displaySlot) {
        return sprites[type * 10 + displaySlot];
    }

    public static Sprite GetUpgradeImage(string upgradeName) {
        switch (upgradeName) {
            case "Delay":  case "Reload Time": return upgradeSprites[0];
            case "Fire Rate": return upgradeSprites[1];
            case "Damage": return upgradeSprites[2];
            case "Duration": return upgradeSprites[3];
            case "Bounce Limit": return upgradeSprites[4];
            case "Knockback": return upgradeSprites[5];
            case "Recoil": return upgradeSprites[6];
            case "Speed": return upgradeSprites[7];
            case "Size": return upgradeSprites[8];
            case "Pellets": return upgradeSprites[9];
            case "Targets": return upgradeSprites[10];
            case "Spread": return upgradeSprites[11];
            case "Capacity": return upgradeSprites[12];
            case "Heal Amount": return upgradeSprites[13];
            default: return blankButtonSprite;
        }
    }
}
