using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioPlayer : MonoBehaviour {

    [SerializeField] AudioSource _audio;

    private int nextShootSFXFrame;
    private const int SHOOT_SFX_INT = 1;

    void Start() { 
        nextShootSFXFrame = -1;
    }

    public void Stop() { 
        _audio.Stop(); 
    }

    public void ButtonSFX() { AudioHandler.Play(_audio, AudioHandler.BUTTON); }

    public void MenuSFX() { AudioHandler.Play(_audio, AudioHandler.MENU); }

    public void GameSFX() { AudioHandler.Play(_audio, AudioHandler.GAME); }

    public void JumpSFX() { AudioHandler.Play(_audio, AudioHandler.JUMP); }

    public void LandSFX() { AudioHandler.Play(_audio, AudioHandler.LAND); }

    public void BigLandSFX() { AudioHandler.Play(_audio, AudioHandler.BIG_LAND); }

    public void HurtSFX() { AudioHandler.Play(_audio, AudioHandler.HURT); }

    public void ShootPewPewSFX() { 
        if (Time.frameCount < nextShootSFXFrame) return;
        AudioHandler.Play(_audio, AudioHandler.SHOOT_PEWPEW);
        nextShootSFXFrame = Time.frameCount + SHOOT_SFX_INT; }

    public void ShootPrrrrrSFX() { 
        if (Time.frameCount < nextShootSFXFrame) return;
        AudioHandler.Play(_audio, AudioHandler.SHOOT_PRRRRR); 
        nextShootSFXFrame = Time.frameCount + SHOOT_SFX_INT; }

    public void ShootBamBamSFX() { 
        if (Time.frameCount < nextShootSFXFrame) return;
        AudioHandler.Play(_audio, AudioHandler.SHOOT_BAMBAM, 0.9f, 1.1f); 
        nextShootSFXFrame = Time.frameCount + SHOOT_SFX_INT; }

    public void ShootGlukSFX() { 
        if (Time.frameCount < nextShootSFXFrame) return;
        AudioHandler.Play(_audio, AudioHandler.SHOOT_GLUK, 0.9f, 1.1f); 
        nextShootSFXFrame = Time.frameCount + SHOOT_SFX_INT; }

    public void ShootPowPowSFX() { 
        if (Time.frameCount < nextShootSFXFrame) return;
        AudioHandler.Play(_audio, AudioHandler.SHOOT_POWPOW, 0.9f, 1.1f); 
        nextShootSFXFrame = Time.frameCount + SHOOT_SFX_INT; }

    public void ShootBrrrrrSFX() { 
        if (Time.frameCount < nextShootSFXFrame) return;
        AudioHandler.Play(_audio, AudioHandler.SHOOT_BRRRRR); 
        nextShootSFXFrame = Time.frameCount + SHOOT_SFX_INT; }

    public void ShootPtttttSFX() { 
        if (Time.frameCount < nextShootSFXFrame) return;
        AudioHandler.Play(_audio, AudioHandler.SHOOT_PTTTTT); 
        nextShootSFXFrame = Time.frameCount + SHOOT_SFX_INT; }

    public void ShootSplatSFX() { 
        if (Time.frameCount < nextShootSFXFrame) return;
        AudioHandler.Play(_audio, AudioHandler.SHOOT_SPLAT); 
        nextShootSFXFrame = Time.frameCount + SHOOT_SFX_INT; }

    public void ShootPokPokSFX() { 
        if (Time.frameCount < nextShootSFXFrame) return;
        AudioHandler.Play(_audio, AudioHandler.SHOOT_POKPOK, 0.95f, 1.05f); 
        nextShootSFXFrame = Time.frameCount + SHOOT_SFX_INT; }

    public void ShootMissSFX() { 
        if (Time.frameCount < nextShootSFXFrame) return;
        AudioHandler.Play(_audio, AudioHandler.SHOOT_MISS, 0.8f, 1.2f); 
        nextShootSFXFrame = Time.frameCount + SHOOT_SFX_INT; }

    public void CoinSFX() { AudioHandler.Play(_audio, AudioHandler.COIN, 0.8f, 1.2f); }

    public void CoinUseSFX() { AudioHandler.Play(_audio, AudioHandler.COIN_USE, 0.8f, 1.2f); }

    public void EmeraldSFX() { AudioHandler.Play(_audio, AudioHandler.EMERALD, 0.8f, 1.2f); }

    public void EmeraldUseSFX() { AudioHandler.Play(_audio, AudioHandler.EMERALD_USE, 0.8f, 1.2f); }

    public void AmethystSFX() { AudioHandler.Play(_audio, AudioHandler.AMETHYST, 0.8f, 1.2f); }

    public void AmethystUseSFX() { AudioHandler.Play(_audio, AudioHandler.AMETHYST_USE, 0.8f, 1.2f); }

    public void SlashSwooshSFX() { AudioHandler.Play(_audio, AudioHandler.SLASH_SWOOSH, 0.9f, 1.1f); }

    public void SlashShapSFX() { AudioHandler.Play(_audio, AudioHandler.SLASH_SHAP, 0.9f, 1.1f); }

    public void SlashChchingSFX() { AudioHandler.Play(_audio, AudioHandler.SLASH_CHCHING, 0.9f, 1.1f); }

    public void SlashShingSFX() { AudioHandler.Play(_audio, AudioHandler.SLASH_SHING, 0.9f, 1.1f); }

    public void SlashSchingSFX() { AudioHandler.Play(_audio, AudioHandler.SLASH_SCHING, 0.9f, 1.1f); }

    public void ShazamPrrrupSFX() { AudioHandler.Play(_audio, AudioHandler.SHAZAM_PRRRUP, 0.9f, 1.1f); }

    public void ShazamZwoomSFX() { AudioHandler.Play(_audio, AudioHandler.SHAZAM_ZWOOM, 0.9f, 1.1f); }

    public void ShazamBdzgdfzzSFX() { AudioHandler.Play(_audio, AudioHandler.SHAZAM_BDZGDFZZ); }

    public void BounceSFX() { AudioHandler.Play(_audio, AudioHandler.BOUNCE, 0.9f, 1.1f); }

    public void SquishSFX() { AudioHandler.Play(_audio, AudioHandler.SQUISH, 0.8f, 1.2f); }

    public void PopSFX() { AudioHandler.Play(_audio, AudioHandler.POP, 0.8f, 1.2f); }

    public void PipeMoveSFX() { AudioHandler.Play(_audio, AudioHandler.PIPE_MOVE); }

    public void PipePumpSFX() { AudioHandler.Play(_audio, AudioHandler.PIPE_PUMP, 0.9f, 1.1f); }

    public void BrickSFX() { AudioHandler.Play(_audio, AudioHandler.BRICK, 0.9f, 1.1f); }

    public void GroundSFX() { AudioHandler.Play(_audio, AudioHandler.GROUND, 0.9f, 1.1f); }

    public void FallSFX() { AudioHandler.Play(_audio, AudioHandler.FALL); }

    public void RoundWinSFX() { AudioHandler.Play(_audio, AudioHandler.ROUND_WIN); }

    public void RoundLoseSFX() { AudioHandler.Play(_audio, AudioHandler.ROUND_LOSE); }

    public void GameOverSFX() { AudioHandler.Play(_audio, AudioHandler.GAME_OVER); }

    public void ReloadStartSFX() { AudioHandler.Play(_audio, AudioHandler.RELOAD_START, 0.9f, 1.1f); }

    public void ReloadFinishSFX() { AudioHandler.Play(_audio, AudioHandler.RELOAD_FINISH, 0.9f, 1.1f); }
}
