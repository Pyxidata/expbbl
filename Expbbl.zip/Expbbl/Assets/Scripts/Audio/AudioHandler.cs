using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioHandler : MonoBehaviour {

    // UI
    public static AudioClip BUTTON;
    public static AudioClip MENU;
    public static AudioClip GAME;

    // Player
    public static AudioClip JUMP;
    public static AudioClip LAND;
    public static AudioClip BIG_LAND;
    public static AudioClip HURT;
    public static AudioClip FALL;

    // Bubble
    public static AudioClip BOUNCE;
    public static AudioClip SQUISH;
    public static AudioClip POP;

    // Game
    public static AudioClip ROUND_WIN;
    public static AudioClip ROUND_LOSE;
    public static AudioClip GAME_OVER;

    // Objects
    public static AudioClip PIPE_MOVE;
    public static AudioClip PIPE_PUMP;
    public static AudioClip BRICK;
    public static AudioClip GROUND;

    // Pickup
    public static AudioClip COIN;
    public static AudioClip COIN_USE;
    public static AudioClip EMERALD;
    public static AudioClip EMERALD_USE;
    public static AudioClip AMETHYST;
    public static AudioClip AMETHYST_USE;

    // Reload
    public static AudioClip RELOAD_START;
    public static AudioClip RELOAD_FINISH;

    // Shooters
    public static AudioClip SHOOT_PEWPEW;
    public static AudioClip SHOOT_PRRRRR;
    public static AudioClip SHOOT_BAMBAM;
    public static AudioClip SHOOT_GLUK;
    public static AudioClip SHOOT_POWPOW;
    public static AudioClip SHOOT_BRRRRR;
    public static AudioClip SHOOT_PTTTTT;
    public static AudioClip SHOOT_SPLAT;
    public static AudioClip SHOOT_POKPOK;
    public static AudioClip SHOOT_MISS;

    // Slashers
    public static AudioClip SLASH_SWOOSH;
    public static AudioClip SLASH_SHAP;
    public static AudioClip SLASH_CHCHING;
    public static AudioClip SLASH_SHING;
    public static AudioClip SLASH_SCHING;

    // Shazams
    public static AudioClip SHAZAM_PRRRUP;
    public static AudioClip SHAZAM_ZWOOM;
    public static AudioClip SHAZAM_BDZGDFZZ;

    public static void Init() {
        BUTTON = Resources.Load<AudioClip>("Audio/button");
        MENU = Resources.Load<AudioClip>("Audio/menu");
        GAME = Resources.Load<AudioClip>("Audio/ground");

        JUMP = Resources.Load<AudioClip>("Audio/jump");
        LAND = Resources.Load<AudioClip>("Audio/land");
        BIG_LAND = Resources.Load<AudioClip>("Audio/big_land");
        HURT = Resources.Load<AudioClip>("Audio/hurt");
        FALL = Resources.Load<AudioClip>("Audio/fall");

        BOUNCE = Resources.Load<AudioClip>("Audio/bounce");
        SQUISH = Resources.Load<AudioClip>("Audio/squish");
        POP = Resources.Load<AudioClip>("Audio/pop");

        ROUND_WIN = Resources.Load<AudioClip>("Audio/round_win");
        ROUND_LOSE = Resources.Load<AudioClip>("Audio/round_lose");
        GAME_OVER = Resources.Load<AudioClip>("Audio/game_over");

        PIPE_MOVE = Resources.Load<AudioClip>("Audio/pipe_move");
        PIPE_PUMP = Resources.Load<AudioClip>("Audio/pipe_pump");
        BRICK = Resources.Load<AudioClip>("Audio/brick");
        GROUND = Resources.Load<AudioClip>("Audio/ground");

        COIN = Resources.Load<AudioClip>("Audio/coin");
        COIN_USE = Resources.Load<AudioClip>("Audio/coin_use");
        EMERALD = Resources.Load<AudioClip>("Audio/emerald");
        EMERALD_USE = Resources.Load<AudioClip>("Audio/emerald_use");
        AMETHYST = Resources.Load<AudioClip>("Audio/amethyst");
        AMETHYST_USE = Resources.Load<AudioClip>("Audio/amethyst_use");

        RELOAD_START = Resources.Load<AudioClip>("Audio/reload_start");
        RELOAD_FINISH = Resources.Load<AudioClip>("Audio/reload_finish");

        SHOOT_PEWPEW = Resources.Load<AudioClip>("Audio/shoot_pewpew");
        SHOOT_PRRRRR = Resources.Load<AudioClip>("Audio/shoot_prrrrr");
        SHOOT_BAMBAM = Resources.Load<AudioClip>("Audio/shoot_bambam");
        SHOOT_GLUK = Resources.Load<AudioClip>("Audio/shoot_gluk");
        SHOOT_POWPOW = Resources.Load<AudioClip>("Audio/shoot_powpow");
        SHOOT_BAMBAM = Resources.Load<AudioClip>("Audio/shoot_bambam");
        SHOOT_BRRRRR = Resources.Load<AudioClip>("Audio/shoot_brrrrr");
        SHOOT_PTTTTT = Resources.Load<AudioClip>("Audio/shoot_pttttt");
        SHOOT_SPLAT = Resources.Load<AudioClip>("Audio/shoot_splat");
        SHOOT_POKPOK = Resources.Load<AudioClip>("Audio/shoot_pokpok");
        SHOOT_MISS = Resources.Load<AudioClip>("Audio/shoot_miss");

        SLASH_SWOOSH = Resources.Load<AudioClip>("Audio/slash_swoosh");
        SLASH_SHAP = Resources.Load<AudioClip>("Audio/slash_shap");
        SLASH_CHCHING = Resources.Load<AudioClip>("Audio/slash_chching");
        SLASH_SHING = Resources.Load<AudioClip>("Audio/slash_shing");
        SLASH_SCHING = Resources.Load<AudioClip>("Audio/slash_sching");

        SHAZAM_PRRRUP = Resources.Load<AudioClip>("Audio/shazam_prrrup");
        SHAZAM_ZWOOM = Resources.Load<AudioClip>("Audio/shazam_zwoom");
        SHAZAM_BDZGDFZZ = Resources.Load<AudioClip>("Audio/shazam_bdzgdfzz");
    }

    public static void Play(AudioSource source, AudioClip clip) {
        source.pitch = (1.0f);
        source.PlayOneShot(clip);
    }

    public static void Play(AudioSource source, AudioClip clip, float minPitch, float maxPitch) {
        source.pitch = (Random.Range(minPitch, maxPitch));
        source.PlayOneShot(clip);
    }

}