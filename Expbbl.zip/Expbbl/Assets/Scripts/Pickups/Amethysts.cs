using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Amethysts : MonoBehaviour {

    ParticleSystem ps;
    ParticleSystem.Particle[] particles;

    private GameObject player;
    private AudioPlayer _audio;

    private float speed;

    private void Awake() {
        ps = GetComponent<ParticleSystem>();
        particles = new ParticleSystem.Particle[ps.main.maxParticles];
        speed = 0.000001f;
    }

    private void Update() {

        speed *= 1.4f;
        int particleCount = ps.GetParticles(particles);

        for (int i = 0; i < particleCount; i++)
            particles[i].velocity += (player.transform.position - particles[i].position - gameObject.transform.position) * speed;

        ps.SetParticles(particles, particleCount);
    }

    public void LateInit(GameObject player) {
        this.player = player;
        _audio = player.GetComponent<AudioPlayer>();

        var e = ps.emission;
        e.SetBurst(0, new ParticleSystem.Burst(0.001f, 1));
    }

    void OnParticleCollision(GameObject other) {

        BackgroundScript.AddAmethysts(1);
        _audio.AmethystSFX();
    }

}
