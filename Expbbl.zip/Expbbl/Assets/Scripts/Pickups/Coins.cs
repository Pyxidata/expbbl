using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coins : MonoBehaviour {

    ParticleSystem ps;
    ParticleSystem.Particle[] particles;

    private GameObject player;
    private PlayerStats playerStats;
    private int value;
    private int count;

    private float speed;

    private void Awake() {
        ps = GetComponent<ParticleSystem>();
        particles = new ParticleSystem.Particle[ps.main.maxParticles];
        speed = 0.000001f;
    }

    private void Update() {

        speed *= 1.4f;
        int particleCount = ps.GetParticles(particles);

        for (int i = 0; i < particleCount; i++)
            particles[i].velocity += (player.transform.position - particles[i].position - gameObject.transform.position) * speed;

        ps.SetParticles(particles, particleCount);
    }

    public void LateInit(PlayerStats playerStats, int value, float radius) {
        this.player = playerStats.gameObject;
        this.playerStats = playerStats;

        count = (int)Mathf.Max(1, Mathf.Log(value, 3) - 3);
        this.value = value / count;

        var s = ps.shape;
        s.radius = radius;

        var e = ps.emission;
        e.SetBurst(0, new ParticleSystem.Burst(0.001f, count));
    }

    void OnParticleCollision(GameObject other) {

        playerStats.AddCoins(value);
    }

}
