using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Util {

    // Maximum integer to be handled; greater values should be reduced to this
    public const int MAX_INT = 1000000000;

    // Round to the nearest thousandth digit (convention for display)
    public static float Round(float x) {
        return Mathf.Round(x * 1000.0f) / 1000.0f;
    }

    // Simplify (round) to 3 largest significant digits (convention for prices)
    public static int Simplify(float x) {
        int k = (int)Mathf.Pow(10, Digits(x) - 3);
        return (k <= 0) ? (int) x : (int)(Mathf.Round((float)(x / k)) * k);
    }

    // Counts the number of digits
    public static int Digits(float x) {
        return (int)Mathf.Floor(Mathf.Log10(x) + 1);
    }

    // Exponential function of range [1, cap] within the domain of [x, xMax]; used in calculating upgrade prices
    public static float CappedExp(int x, int xMax, int cap) {
        return Mathf.Pow(Mathf.Pow(cap, 1.0f / xMax), x);
    }

    // Returns the magnitude of the 2D vector
    public static float Mag(Vector2 v) {
        return Mathf.Sqrt(v.x * v.x + v.y * v.y);
    }

    // Returns the distance between two 2D points
    public static float Dist(Vector2 p1, Vector2 p2) {
        return Mathf.Sqrt(Mathf.Abs(p1.x * p2.x) + Mathf.Abs(p1.y * p2.y));
    }

    // Returns -1 or 1 (50% chance for each)
    public static float RandomSign() {
        return (Random.value > 0.5f) ? -1 : 1;
    }
}
