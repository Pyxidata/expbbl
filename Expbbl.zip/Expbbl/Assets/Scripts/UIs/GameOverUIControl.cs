using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameOverUIControl : MonoBehaviour {

    private GameHandler game;

    private void Awake() {
        game = GameObject.Find("Game Handler").GetComponent<GameHandler>();
    }

    public void Retry() {
        gameObject.SetActive(false);
        Time.timeScale = 1.0f;
        game.Reset();
    }

    public void Exit() {
        gameObject.SetActive(false);
        Time.timeScale = 1.0f;
        BackgroundScript.ToMenuScene();
    }
}