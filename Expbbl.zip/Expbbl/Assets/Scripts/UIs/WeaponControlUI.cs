using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponControlUI : MonoBehaviour {

    [SerializeField] GameObject player;
    private PlayerController controllers;

    private void Awake() {
        controllers = player.GetComponent<PlayerController>();
    }

    public void SelectUseUp() { controllers.useUpHeld = true; }

    public void SelectUseDown() { controllers.useDownHeld = true; }

    public void SelectUseLeft() { controllers.useLeftHeld = true; }

    public void SelectUseRight() { controllers.useRightHeld = true; }

    public void DeselectUseUp() { controllers.useUpHeld = false; }

    public void DeselectUseDown() { controllers.useDownHeld = false; }

    public void DeselectUseLeft() { controllers.useLeftHeld = false; }

    public void DeselectUseRight() { controllers.useRightHeld = false; }

}