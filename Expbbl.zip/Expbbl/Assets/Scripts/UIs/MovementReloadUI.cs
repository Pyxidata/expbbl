using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovementReloadUI : MonoBehaviour {

    [SerializeField] GameObject player;
    private PlayerController controllers;

    private void Awake() {
        controllers = player.GetComponent<PlayerController>();
    }

    public void SelectUp() { controllers.upHeld = true; }

    public void SelectDown() { controllers.downHeld = true; }

    public void SelectLeft() { controllers.leftHeld = true; }

    public void SelectRight() { controllers.rightHeld = true; }

    public void SelectReload() { controllers.reloadHeld = true; }

    public void DeselectUp() { controllers.upHeld = false; }

    public void DeselectDown() { controllers.downHeld = false; }

    public void DeselectLeft() { controllers.leftHeld = false; }

    public void DeselectRight() { controllers.rightHeld = false; }

    public void DeselectReload() { controllers.reloadHeld = false; }

}