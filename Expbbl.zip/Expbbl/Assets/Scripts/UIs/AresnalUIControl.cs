using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AresnalUIControl : MonoBehaviour {

    [SerializeField] GameObject SuperUI;
    [SerializeField] GameObject UI;
    private AudioPlayer _audio;

    private int currType;

    private GameObject typeComponents;
    private GameObject weaponComponents;

    private Button[/*weapon# [0, 8]*/] weaponBtn; // weapon buy button
    private Text[/*weapon# [0, 8]*/] weaponBtnTxt; // weapon buy button texts

    private void Awake() {
        _audio = SuperUI.GetComponent<AudioPlayer>();

        currType = 0;

        typeComponents = UI.transform.GetChild(0).gameObject;
        weaponComponents = UI.transform.GetChild(1).gameObject;

        weaponBtn = new Button[9];
        weaponBtnTxt = new Text[9];
        for (int weapon = 0; weapon < 9; weapon++) {
            weaponBtn[weapon] = weaponComponents.transform.GetChild(weapon).GetComponent<Button>();
            weaponBtnTxt[weapon] = weaponComponents.transform.GetChild(weapon).transform.GetChild(0).GetComponent<Text>();
        }
    }

    // Open Functions ////////////////////////////////////////////////////////////

    public void OpenArsenal() {
        typeComponents.SetActive(true);
        weaponComponents.SetActive(false);
        UI.SetActive(true);
    }

    public void OpenWeapons(int type) {
        UpdateWeaponsInfo(type);
        typeComponents.SetActive(false);
        weaponComponents.SetActive(true);
    }

    // Action Functions ////////////////////////////////////////////////////////////

    public void QuitGame() {
        BackgroundScript.Quit();
    }

    public void Unlock(int type, int displaySlot) {

        if (type == 2 && BackgroundScript.AddAmethysts(-WeaponsHandler.GetUnlockPrice(type, displaySlot))) {
            WeaponsHandler.available[type * 10 + displaySlot] = true;
            BackgroundScript.UpdateSaveData();
            _audio.AmethystUseSFX();
        }

        else if (BackgroundScript.AddEmeralds(-WeaponsHandler.GetUnlockPrice(type, displaySlot))) {
            WeaponsHandler.available[type * 10 + displaySlot] = true;
            BackgroundScript.UpdateSaveData();
            _audio.EmeraldUseSFX();
        }
        UpdateWeaponsInfo(type);
    }

    // Return Functions ////////////////////////////////////////////////////////////

    public void Return() {
        typeComponents.SetActive(true);
        weaponComponents.SetActive(false);
        UI.SetActive(false);
    }

    public void BackFromWeapons() {
        weaponComponents.SetActive(false);
        typeComponents.SetActive(true);
    }

    private void UpdateWeaponsInfo(int type) {

        currType = type;

        for (int displaySlot = 0; displaySlot < 9; displaySlot++) {

            weaponBtn[displaySlot].image.sprite = WeaponsHandler.GetSmallImage(type, displaySlot);

            int price = WeaponsHandler.GetUnlockPrice(type, displaySlot);
            int ID = type * 10 + displaySlot;

            if (price == -1) weaponBtnTxt[displaySlot].text = "???";
            else if (WeaponsHandler.available[ID]) weaponBtnTxt[displaySlot].text = "Unlocked";
            else if (type == 2) weaponBtnTxt[displaySlot].text = price + " Amethysts";
            else weaponBtnTxt[displaySlot].text = price + " Emeralds";

            if (type == 2 && (WeaponsHandler.available[ID] || price > BackgroundScript.amethysts || price <= 0)) {
                weaponBtn[displaySlot].interactable = false;
                continue;

            } else if (type != 2 && (WeaponsHandler.available[ID] || price > BackgroundScript.emeralds || price <= 0)) {
                weaponBtn[displaySlot].interactable = false;
                continue;
            }

            weaponBtn[displaySlot].onClick.RemoveAllListeners();
            int t = type;
            int d = displaySlot;
            weaponBtn[displaySlot].onClick.AddListener(() => Unlock(t, d));
            weaponBtn[displaySlot].interactable = true;
        }
    }
}