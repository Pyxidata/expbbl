using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WeaponSlotSelectors : MonoBehaviour {

    private Color activeColor = new Color(0.9f, 0.9f, 0.9f, 1.0f);
    private Color passiveColor = new Color(0.283f, 0.283f, 0.283f, 1.0f);

    [SerializeField] GameObject player;
    private PlayerWeapons weapons;
    private PlayerController controllers;
    private AudioPlayer _audio;

    private Text _text1, _subText1;
    private Text _text2, _subText2;
    private Text _text3, _subText3;
    private Text _text4, _subText4;

    private void Awake() {
        var child = gameObject.transform.GetChild(0);
        _text1 = child.transform.GetChild(0).GetComponent<Text>();
        _subText1 = child.transform.GetChild(0).transform.GetChild(0).GetComponent<Text>();

        child = gameObject.transform.GetChild(1);
        _text2 = child.transform.GetChild(0).GetComponent<Text>();
        _subText2 = child.transform.GetChild(0).transform.GetChild(0).GetComponent<Text>();

        child = gameObject.transform.GetChild(2);
        _text3 = child.transform.GetChild(0).GetComponent<Text>();
        _subText3 = child.transform.GetChild(0).transform.GetChild(0).GetComponent<Text>();

        child = gameObject.transform.GetChild(3);
        _text4 = child.transform.GetChild(0).GetComponent<Text>();
        _subText4 = child.transform.GetChild(0).transform.GetChild(0).GetComponent<Text>();

        controllers = player.GetComponent<PlayerController>();
        weapons = controllers.weapons;
        _audio = player.GetComponent<AudioPlayer>();
    }

    private void Update() {
        _text1.text = weapons.GetName(0);
        _subText1.text = weapons.GetMagazineLabel(0);

        _text2.text = weapons.GetName(1);
        _subText2.text = weapons.GetMagazineLabel(1);

        _text3.text = weapons.GetName(2);
        _subText3.text = weapons.GetMagazineLabel(2);

        _text4.text = weapons.GetName(3);
        _subText4.text = weapons.GetMagazineLabel(3);

        _text1.color = (weapons.selectedSlot == 0) ? activeColor : passiveColor;
        _text2.color = (weapons.selectedSlot == 1) ? activeColor : passiveColor;
        _text3.color = (weapons.selectedSlot == 2) ? activeColor : passiveColor;
        _text4.color = (weapons.selectedSlot == 3) ? activeColor : passiveColor;
    }

    public void Select1() { controllers.slot1Held = true; _audio.ButtonSFX(); }

    public void Select2() { controllers.slot2Held = true; _audio.ButtonSFX(); }

    public void Select3() { controllers.slot3Held = true; _audio.ButtonSFX(); }

    public void Select4() { controllers.slot4Held = true; _audio.ButtonSFX(); }

    public void Deselect1() { controllers.slot1Held = false; }

    public void Deselect2() { controllers.slot2Held = false; }

    public void Deselect3() { controllers.slot3Held = false; }

    public void Deselect4() { controllers.slot4Held = false; }
}