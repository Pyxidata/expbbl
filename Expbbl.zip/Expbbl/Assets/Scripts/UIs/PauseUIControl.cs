using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PauseUIControl : MonoBehaviour {

    [SerializeField] GameObject UI;
    [SerializeField] GameObject PauseUI;
    [SerializeField] GameObject RestartUI;
    [SerializeField] GameObject ExitUI;

    [SerializeField] GameObject gameHandler;
    [SerializeField] GameObject player;
    [SerializeField] GameObject bubbleLevelBtn;

    private GameHandler game;
    private AudioSource topAudio;
    private AudioSource playerAudio;
    private PlayerController playerController;
    private Text bubbleLevelBtnTxt;

    private bool paused = false;

    private void Awake() {
        game = GameObject.Find("Game Handler").GetComponent<GameHandler>();
        topAudio = gameHandler.GetComponent<AudioSource>();
        playerAudio = player.GetComponent<AudioSource>();
        playerController = player.GetComponent<PlayerController>();
        bubbleLevelBtnTxt = bubbleLevelBtn.GetComponent<Text>();
    }

    public void Pause() {
        UI.SetActive(true);
        PauseUI.SetActive(true);
        RestartUI.SetActive(false);
        ExitUI.SetActive(false);

        Time.timeScale = 0.0f;
        paused = true;
        topAudio.Pause();
        playerAudio.Pause();
    }

    public void Resume() {
        UI.SetActive(false);
        Time.timeScale = 1.0f;
        paused = false;
        topAudio.UnPause();
        playerAudio.UnPause();
    }

    public void Restart() {
        PauseUI.SetActive(false);
        RestartUI.SetActive(true);
    }

    public void ConfirmRestart() {
        UI.SetActive(false);
        Time.timeScale = 1.0f;
        paused = false;
        game.Reset();
    }

    public void Exit() {
        PauseUI.SetActive(false);
        ExitUI.SetActive(true);
    }

    public void ConfirmExit() {
        Time.timeScale = 1.0f;
        paused = false;
        BackgroundScript.ToMenuScene();
    }

    public void Back() {
        PauseUI.SetActive(true);
        RestartUI.SetActive(false);
        ExitUI.SetActive(false);
    }

    public void ToggleBubbleLevelDisplayMode() {
        BackgroundScript.showBubbleLevel  = !BackgroundScript.showBubbleLevel;
        bubbleLevelBtnTxt.text = BackgroundScript.showBubbleLevel ? "Bubble Lv. Shown" : "Bubble Lv. Hidden";
    }

    private void Update() {
        if (Input.GetButtonDown("ESC")) {
            if (paused) Resume();
            else Pause();
        }
    }
}
