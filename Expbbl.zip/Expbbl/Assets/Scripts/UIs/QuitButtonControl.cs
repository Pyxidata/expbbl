using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuitButtonControl : MonoBehaviour {

    public void QuitGame() {
        BackgroundScript.Quit();
    }
}
