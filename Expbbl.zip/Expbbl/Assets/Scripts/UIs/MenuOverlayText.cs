using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuOverlayText : MonoBehaviour {

    [SerializeField] Text emeraldTxt;
    [SerializeField] Text amethystTxt;
    [SerializeField] AudioPlayer _audio;

    private void Awake() {
        _audio.MenuSFX();
    }

    private void Update() {
        emeraldTxt.text = BackgroundScript.emeralds + "";
        amethystTxt.text = BackgroundScript.amethysts + "";
    }
}