using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerStatsText : MonoBehaviour {

    private PlayerStats stats;
    private Text _subText1;
    private Text _subText2;
    private Text _subText3;
    private Text _subText4;

    private void Awake() {
        stats = GameObject.Find("Player").GetComponent<PlayerStats>();

        var child = gameObject.transform.GetChild(0);
        _subText1 = child.transform.GetChild(0).GetComponent<Text>();

        child = gameObject.transform.GetChild(1);
        _subText2 = child.transform.GetChild(0).GetComponent<Text>();

        child = gameObject.transform.GetChild(2);
        _subText3 = child.transform.GetChild(0).GetComponent<Text>();

        child = gameObject.transform.GetChild(3);
        _subText4 = child.transform.GetChild(0).GetComponent<Text>();
    }

    private void Update() {
        _subText1.text = stats.round + "";
        _subText2.text = stats.lives + "";
        _subText3.text = stats.health + " / " + stats.maxHealth;
        _subText4.text = stats.coins + "";
    }
}