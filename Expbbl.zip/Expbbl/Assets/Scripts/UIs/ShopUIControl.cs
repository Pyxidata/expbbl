using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ShopUIControl : MonoBehaviour {

    [SerializeField] GameObject UI;
    [SerializeField] GameObject gameHandler;

    private GameObject player;
    private PlayerStats stats;
    private PlayerController controller;
    private PlayerWeapons weapons;
    private AudioSource topAudio;

    private bool inShop = false;
    private int currSlot;
    private bool[] hasWeapon;
    private int currType;

    // UI Bundles
    private GameObject shopComponents;
    private GameObject weaponComponents;
    private GameObject buyTypeComponents;
    private GameObject buyComponents;
    private GameObject sellComponents;
    private GameObject playerComponents;
    private GameObject swapComponents;

    // Shop UI
    private Button[] weaponBtn;
    private Text[] weaponBtnTxt;

    // Weapon UI
    private Button[] upgrBtn; // upgrade buttons
    private Button swapBtn; // slot swap button
    private Button modeBtn; // weapon attack mode button
    private Text slotEditBtnTxt; // slot edit button text
    private Text modeBtnTxt; // weapon attack mode button text
    private Text[/*upgrade# [0, 3]*/][/*upgradeTxt [title, subtitle, description, price]*/] upgrTxt; // upgrade button texts

    // Buy UI
    private Button[/*weapon# [0, 8]*/] buyBtn; // weapon buy button
    private Text[/*weapon# [0, 8]*/] buyBtnTxt; // weapon buy button texts

    // Sell UI
    private Button sellBtn;
    private Text sellBtnTxt; // sell button text

    // Player UI
    private Button[/*upgrade# [0, 2]*/] playerBtn; // player upgrade button texts
    private Text[/*upgrade# [0, 2]*/][/*upgradeTxt [title, subtitle, description, price]*/] playerTxt; // player upgrade buy button

    // Swap UI
    private Button[/*slot# [0, 3]*/] swapSlotBtn; // swap slot buttons
    private Text[/*slot# [0, 3]*/] swapSlotBtnTxt; // swap slot button texts

    private void Awake() {

        player = GameObject.Find("Player");
        stats = player.GetComponent<PlayerStats>();
        controller = player.GetComponent<PlayerController>();
        topAudio = gameHandler.GetComponent<AudioSource>();
        currSlot = 0;
        currType = 0;

        hasWeapon = new bool[4];
        for (int slot = 0; slot < 4; slot++)
            hasWeapon[slot] = true;

        // UI Bundles
        shopComponents = UI.transform.GetChild(0).gameObject;
        weaponComponents = UI.transform.GetChild(1).gameObject;
        buyTypeComponents = UI.transform.GetChild(2).gameObject;
        buyComponents = UI.transform.GetChild(3).gameObject;
        sellComponents = UI.transform.GetChild(4).gameObject;
        playerComponents = UI.transform.GetChild(5).gameObject;
        swapComponents = UI.transform.GetChild(6).gameObject;

        // Shop UI - Weapon selection button texts
        weaponBtn = new Button[4];
        weaponBtnTxt = new Text[4];
        for (int slot = 0; slot < 4; slot++) {
            weaponBtn[slot] = shopComponents.transform.GetChild(slot).GetComponent<Button>();
            weaponBtnTxt[slot] = shopComponents.transform.GetChild(slot).transform.GetChild(0).GetComponent<Text>();
        }

        // Weapon UIs - Weapon upgrade misc. buttons/texts
        slotEditBtnTxt = weaponComponents.transform.GetChild(0).transform.GetChild(0).GetComponent<Text>();
        swapBtn = weaponComponents.transform.GetChild(5).GetComponent<Button>();
        modeBtn = weaponComponents.transform.GetChild(6).GetComponent<Button>();
        modeBtnTxt = weaponComponents.transform.GetChild(6).GetChild(0).GetComponent<Text>();

        // Weapon upgrade buttons
        upgrTxt = new Text[4][];
        upgrBtn = new Button[4];
        for (int upgr = 0; upgr < 4; upgr++) {
            upgrTxt[upgr] = new Text[5];
            Transform c = weaponComponents.transform.GetChild(upgr + 1);
            upgrBtn[upgr] = c.GetComponent<Button>();

            for (int txt = 0; txt < 5; txt++) {
                upgrTxt[upgr][txt] = c.GetChild(txt).GetComponent<Text>();
            }
        }

        // Weapon buy buttons
        buyBtn = new Button[9];
        buyBtnTxt = new Text[9];
        for (int weapon = 0; weapon < 9; weapon++) {
            buyBtn[weapon] = buyComponents.transform.GetChild(weapon).GetComponent<Button>();
            buyBtnTxt[weapon] = buyComponents.transform.GetChild(weapon).transform.GetChild(0).GetComponent<Text>();
        }

        // Sell button
        sellBtn = sellComponents.transform.GetChild(0).GetComponent<Button>();
        sellBtnTxt = sellComponents.transform.GetChild(0).transform.GetChild(0).GetComponent<Text>();

        // Player upgrade buttons
        playerTxt = new Text[3][];
        playerBtn = new Button[3];
        for (int upgr = 0; upgr < 3; upgr++) {
            playerTxt[upgr] = new Text[4];
            Transform c = playerComponents.transform.GetChild(upgr);
            playerBtn[upgr] = c.GetComponent<Button>();

            for (int txt = 0; txt < 4; txt++) {
                playerTxt[upgr][txt] = c.GetChild(txt).GetComponent<Text>();
            }
        }

        // Swap buttons
        swapSlotBtn = new Button[4];
        swapSlotBtnTxt = new Text[4];
        for (int slot = 0; slot < 4; slot++) {
            swapSlotBtn[slot] = swapComponents.transform.GetChild(slot).GetComponent<Button>();
            swapSlotBtnTxt[slot] = swapComponents.transform.GetChild(slot).transform.GetChild(0).GetComponent<Text>();
        }
    }

    // Open Functions ////////////////////////////////////////////////////////////

    public void OpenShop() {
        if (!stats.IsAlive()) return;

        UpdateShopInfo();
        ResetActiveComponents();

        UI.SetActive(true);
        Time.timeScale = 0.0f;
        inShop = true;
        topAudio.Pause();
    }

    public void OpenWeapon(int slot) {
        UpdateWeaponsInfo(slot);
        shopComponents.SetActive(false);
        weaponComponents.SetActive(true);
    }

    public void OpenPlayer() {
        UpdatePlayerInfo();
        shopComponents.SetActive(false);
        playerComponents.SetActive(true);
    }

    public void OpenEditSlot() {
        if (hasWeapon[currSlot]) {
            OpenSell();
        } else {
            OpenBuyType();
        }
    }

    private void OpenBuyType() {
        weaponComponents.SetActive(false);
        buyTypeComponents.SetActive(true);
    }

    private void OpenSell() {
        UpdateSellInfo();
        weaponComponents.SetActive(false);
        sellComponents.SetActive(true);
    }

    public void OpenBuy(int type) {
        UpdateBuyInfo(type);
        buyTypeComponents.SetActive(false);
        buyComponents.SetActive(true);
    }

    public void OpenSwap() {
        UpdateSwapInfo();
        weaponComponents.SetActive(false);
        swapComponents.SetActive(true);
    }

    // Action Functions ////////////////////////////////////////////////////////////

    public void ResetActiveComponents() {
        shopComponents.SetActive(true);
        weaponComponents.SetActive(false);
        buyTypeComponents.SetActive(false);
        buyComponents.SetActive(false);
        sellComponents.SetActive(false);
        playerComponents.SetActive(false);
        swapComponents.SetActive(false);
    }

    public void Upgrade(int upgr) {
        weapons.Upgrade(currSlot, upgr);
        UpdateWeaponsInfo(currSlot);
    }

    public void Buy(int type, int displaySlot) { // see UpdateBuyInfo() to see details of how IDs are assigned
        Weapon weapon = WeaponsHandler.GetNew(type, displaySlot, player);

        if (weapon != null && stats.AddCoins(-WeaponsHandler.GetBasePrice(type, displaySlot))) {
            weapons.SetWeapon(currSlot, weapon);
            // play SFX
        }
    }

    public void Sell() {
        stats.AddCoins(weapons.GetSellPrice(currSlot));
        weapons.SetWeapon(currSlot, new Empty());
    }

    public void HealthUpgrade() {
        stats.HealthUpgrade();
        UpdatePlayerInfo();
    }

    public void SpeedUpgrade() {
        controller.SpeedUpgrade(stats);
        UpdatePlayerInfo();
    }

    public void JumpUpgrade() {
        controller.JumpUpgrade(stats);
        UpdatePlayerInfo();
    }

    public void ChangeMode() {
        weapons.ChangeToggleMode(currSlot);
        UpdateWeaponsInfo(currSlot);
    }

    public void SwapWith(int slot) {
        weapons.Swap(currSlot, slot);
        UpdateShopInfo();
    }

    // Return Functions ////////////////////////////////////////////////////////////

    public void Return() {
        ResetActiveComponents();

        UI.SetActive(false);
        Time.timeScale = 1.0f;
        inShop = false;
        topAudio.UnPause();
    }

    public void BackFromWeapon() {
        OpenShop();
    }

    public void BackFromBuyType() {
        buyTypeComponents.SetActive(false);
        weaponComponents.SetActive(true);
    }

    public void BackFromBuy() {
        buyComponents.SetActive(false);
        buyTypeComponents.SetActive(true);
    }

    public void BackFromSell() {
        sellComponents.SetActive(false);
        weaponComponents.SetActive(true);
    }

    public void BackFromPlayer() {
        playerComponents.SetActive(false);
        shopComponents.SetActive(true);
    }

    public void BackFromSwap() {
        OpenShop();
    }

    private void BuyToWeapon() {
        UpdateWeaponsInfo(currSlot);
        buyComponents.SetActive(false);
        weaponComponents.SetActive(true);
    }

    public void SellToShop() {
        Sell();
        OpenShop();
    }

    // Miscellaneous Functions ////////////////////////////////////////////////////////////

    private void Update() {

        if (weapons == null)
            weapons = controller.weapons;

        if (inShop) {
            Time.timeScale = 0.0f;
        }

        if (Input.GetButtonDown("Shop") && stats.IsAlive()) {
            if (inShop) Return();
            else OpenShop();
        }

        if (Input.GetButtonDown("ESC") && stats.IsAlive() && inShop) {
            Return();
        }
    }

    public string GetUpgradeTitle(int slot, int index) {
        return weapons.GetUpgradeTitle(slot, index);
    }

    public string GetUpgradeSubtitle(int slot, int index) {
        return weapons.GetUpgradeSubtitle(slot, index);
    }

    public string GetUpgradeDescription(int slot, int index) {
        return weapons.GetUpgradeDescription(slot, index);
    }

    public int GetUpgradePrice(int slot, int index) {
        return weapons.GetUpgradePrice(slot, index);
    }

    private void UpdateShopInfo() {

        for (int slot = 0; slot < 4; slot++) {
            weaponBtn[slot].image.sprite = weapons.GetWeapon(slot).image;
            weaponBtnTxt[slot].text = weapons.GetWeapon(slot).name;
        }
    }

    private void UpdateWeaponsInfo(int slot) {

        currSlot = slot;
        hasWeapon[slot] = !weapons.IsEmpty(slot);
        slotEditBtnTxt.text = hasWeapon[slot] ? "Sell this weapon" : "Buy a new weapon";

        modeBtn.interactable = !weapons.IsEmpty(slot);
        swapBtn.interactable = modeBtn.interactable;

        modeBtnTxt.text = (weapons.GetToggleMode(slot)) ? "Toggle to Use" : "Select to Use";

        for (int upgr = 0; upgr < 4; upgr++) {

            if (weapons.GetUpgradeTitle(slot, upgr).Equals("N/A") || weapons.GetUpgradePrice(slot, upgr) > stats.coins) {
                upgrBtn[upgr].interactable = false;
            } else {
                upgrBtn[upgr].interactable = true;
            }

            upgrBtn[upgr].image.sprite = WeaponsHandler.GetUpgradeImage(weapons.GetUpgradeName(slot, upgr));
            upgrTxt[upgr][0].text = weapons.GetUpgradeName(slot, upgr);
            upgrTxt[upgr][1].text = weapons.GetUpgradeTitle(slot, upgr);
            upgrTxt[upgr][2].text = weapons.GetUpgradeSubtitle(slot, upgr);
            upgrTxt[upgr][3].text = weapons.GetUpgradeDescription(slot, upgr);
            upgrTxt[upgr][4].text = weapons.GetUpgradePrice(slot, upgr) + " Coins";
        }
    }

    private void UpdateBuyInfo(int type) {

        currType = type;

        for (int displaySlot = 0; displaySlot < 9; displaySlot++) {

            buyBtn[displaySlot].image.sprite = WeaponsHandler.GetSmallImage(type, displaySlot);

            int price = WeaponsHandler.GetBasePrice(type, displaySlot);
            int ID = type * 10 + displaySlot;

            if (price == -1) buyBtnTxt[displaySlot].text = "???";
            else if (!BackgroundScript.availableWeapons[ID]) buyBtnTxt[displaySlot].text = "Locked";
            else buyBtnTxt[displaySlot].text = price + " Coins";

            if (!WeaponsHandler.available[ID] || price > stats.coins || price <= 0) {
                buyBtn[displaySlot].interactable = false;
                continue;
            }

            buyBtn[displaySlot].onClick.RemoveAllListeners();
            int t = type;
            int d = displaySlot;
            buyBtn[displaySlot].onClick.AddListener(() => Buy(t, d));
            buyBtn[displaySlot].onClick.AddListener(BuyToWeapon);
            buyBtn[displaySlot].interactable = true;
        }
    }

    private void UpdateSellInfo() {
        sellBtn.image.sprite = weapons.GetWeapon(currSlot).image;
        sellBtnTxt.text = "Confirm sell for " + weapons.GetSellPrice(currSlot) + " Coins?";
    }

    private void UpdatePlayerInfo() {

        playerTxt[0][0].text = stats.HealthUpgradeTitle();
        playerTxt[0][1].text = stats.HealthUpgradeSubtitle();
        playerTxt[0][2].text = stats.HealthUpgradeDescription();
        playerTxt[0][3].text = stats.HealthUpgradePrice() + " Coins";
        playerBtn[0].interactable = stats.HealthUpgradePrice() <= stats.coins;

        playerTxt[1][0].text = controller.SpeedUpgradeTitle();
        playerTxt[1][1].text = controller.SpeedUpgradeSubtitle();
        playerTxt[1][2].text = controller.SpeedUpgradeDescription();
        playerTxt[1][3].text = controller.SpeedUpgradePrice() + " Coins";
        playerBtn[1].interactable = controller.SpeedUpgradePrice() <= stats.coins;

        playerTxt[2][0].text = controller.JumpUpgradeTitle();
        playerTxt[2][1].text = controller.JumpUpgradeSubtitle();
        playerTxt[2][2].text = controller.JumpUpgradeDescription();
        playerTxt[2][3].text = controller.JumpUpgradePrice() + " Coins";
        playerBtn[2].interactable = controller.JumpUpgradePrice() <= stats.coins;
    }

    private void UpdateSwapInfo() {

        for (int slot = 0; slot < 4; slot++) {
            swapSlotBtn[slot].interactable = currSlot != slot;
            swapSlotBtn[slot].image.sprite = weapons.GetWeapon(slot).image;
            swapSlotBtnTxt[slot].text = weapons.GetWeapon(slot).name;
        }

    }
}
