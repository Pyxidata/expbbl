using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayButtonControl : MonoBehaviour {

    [SerializeField] Text BestRoundTxt;

    private void Update() {
        BestRoundTxt.text = "Best Round: " + BackgroundScript.bestRound;
    }

    public void OpenGame() {
        BackgroundScript.ToGameScene();
    }
}