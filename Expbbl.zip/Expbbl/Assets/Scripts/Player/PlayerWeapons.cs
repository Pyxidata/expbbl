using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerWeapons {

    private const int MAX_WEAPONS = 4;

    private Weapon[] weapons;
    private PlayerStats stats;
    public int selectedSlot { get; set; }

    public PlayerWeapons(GameObject player) {
        weapons = new Weapon[MAX_WEAPONS];
        stats = player.GetComponent<PlayerStats>();
        weapons[0] = new PewPew(player);

        for (int i = 1; i < MAX_WEAPONS; i++)
            weapons[i] = new Empty();
        selectedSlot = 0;
    }

    public void Use(Vector2 vel) {
        if (selectedSlot == -1) return;
        weapons[selectedSlot].Use(vel);
    }

    public void Use(Vector2 vel, int slot) {
        weapons[slot].Use(vel);
    }

    public bool GetToggleMode(int slot) {
        return weapons[slot].toggleMode;
    }

    public void ChangeToggleMode(int slot) {
        weapons[slot].toggleMode = !weapons[slot].toggleMode;
        if (slot == selectedSlot) selectedSlot = -1;
    }

    public bool GetCurrToggleMode() {
        if (selectedSlot == -1) return false;
        return weapons[selectedSlot].toggleMode;
    }

    public Weapon GetWeapon(int slot) {
        return weapons[slot];
    }

    public void SetWeapon(int slot, Weapon weapon) {
        weapons[slot] = weapon;
    }

    public void Swap(int slot1, int slot2) {
        Weapon temp = weapons[slot1];
        weapons[slot1] = weapons[slot2];
        weapons[slot2] = temp;
    }

    public void ClearParticles() {
        for (int i = 0; i < MAX_WEAPONS; i++)
            weapons[i].ClearParticles();
    }

    public void Reload() {
        if (selectedSlot == -1) return;
        weapons[selectedSlot].ForceReload();
    }

    public void Reload(int slot) {
        weapons[slot].ForceReload();
    }

    public void ReloadAllInstantly() {
        for (int i = 0; i < MAX_WEAPONS; i++)
            weapons[i].ForceReloadInstantly();
    }

    public bool IsEmpty(int slot) {
        return weapons[slot] is Empty;
    }

    public string GetName(int slot) {
        return weapons[slot].name;
    }

    public string GetMagazineLabel(int slot) {
        return weapons[slot].GetMagazineLabel();
    }

    public string GetUpgradeName(int slot, int index) {
        switch (index) {
            case 0: return weapons[slot].GetUpgradeName1();
            case 1: return weapons[slot].GetUpgradeName2();
            case 2: return weapons[slot].GetUpgradeName3();
            case 3: return weapons[slot].GetUpgradeName4();
        }
        return "Missing Name";
    }

    public string GetUpgradeTitle(int slot, int index) {
        switch (index) {
            case 0: return weapons[slot].GetUpgradeTitle1();
            case 1: return weapons[slot].GetUpgradeTitle2();
            case 2: return weapons[slot].GetUpgradeTitle3();
            case 3: return weapons[slot].GetUpgradeTitle4();
        }
        return "Missing Title";
    }

    public string GetUpgradeSubtitle(int slot, int index) {
        switch (index) {
            case 0: return weapons[slot].GetUpgradeSubtitle1();
            case 1: return weapons[slot].GetUpgradeSubtitle2();
            case 2: return weapons[slot].GetUpgradeSubtitle3();
            case 3: return weapons[slot].GetUpgradeSubtitle4();
        }
        return "Missing Subtitle";
    }

    public string GetUpgradeDescription(int slot, int index) {
        switch (index) {
            case 0: return weapons[slot].GetUpgradeDescription1();
            case 1: return weapons[slot].GetUpgradeDescription2();
            case 2: return weapons[slot].GetUpgradeDescription3();
            case 3: return weapons[slot].GetUpgradeDescription4();
        }
        return "Missing Description";
    }

    public int GetUpgradePrice(int slot, int index) {
        switch (index) {
            case 0: return weapons[slot].GetUpgradePrice1();
            case 1: return weapons[slot].GetUpgradePrice2();
            case 2: return weapons[slot].GetUpgradePrice3();
            case 3: return weapons[slot].GetUpgradePrice4();
        }
        return 0;
    }

    public void AddSellPrice(int slot, int value) {
        weapons[slot].sellPrice += value;
        if (weapons[slot].sellPrice > Util.MAX_INT)
            weapons[slot].sellPrice = Util.MAX_INT;
    }

    public int GetSellPrice(int slot) {
        return Util.Simplify(weapons[slot].sellPrice);
    }

    public bool Upgrade(int slot, int index) {
        bool upgraded = false;
        int price = 0;
        switch (index) {
            case 0: if (stats.AddCoins(price = -weapons[slot].GetUpgradePrice1()))
                    upgraded = weapons[slot].Upgrade1(); break;
            case 1: if (stats.AddCoins(price = -weapons[slot].GetUpgradePrice2())) 
                    upgraded = weapons[slot].Upgrade2(); break;
            case 2: if (stats.AddCoins(price = -weapons[slot].GetUpgradePrice3())) 
                    upgraded = weapons[slot].Upgrade3(); break;
            case 3: if (stats.AddCoins(price = -weapons[slot].GetUpgradePrice4())) 
                    upgraded = weapons[slot].Upgrade4(); break;
        }
        if (upgraded) AddSellPrice(slot, (int)(-price * 0.9f));
        return upgraded;
    }


}