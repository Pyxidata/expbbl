using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStats : MonoBehaviour {

    [SerializeField] private int DEFAULT_ROUND = 1;
    [SerializeField] private int DEFAULT_LIVES = 3;
    [SerializeField] private int DEFAULT_MAX_HEALTH = 50;
    [SerializeField] private int DEFAULT_COINS = 1000;

    [SerializeField] public AudioPlayer _audio;

    private const int HEALTH_UPGRADE_UNIT = 25;
    private int healthUpgrades;

    private float damageCooldown = 0.5f;
    private float nextDamageTime;

    public int round { get; private set; }
    public int lives { get; set; }
    public int health { get; private set; }
    public int maxHealth { get; set; }
    public int coins { get; private set; }

    // Special effects
    private Rigidbody2D _rigidBody;
    private bool phaseThruBubbles;
    private float phaseDisableTime;
    private int playerLayer;
    private int bubbleTriggerLayer;
    private TrailRenderer _trail;
    private float trailDisableTime;

    private void Awake() {
        _rigidBody = GetComponent<Rigidbody2D>();
        playerLayer = LayerMask.NameToLayer("Player");
        bubbleTriggerLayer = LayerMask.NameToLayer("BubbleTrigger");
        _trail = GetComponent<TrailRenderer>();
        Reset();
    }

    private void Update() {

        // Disable phasing through bubbles at set time
        if (phaseThruBubbles && Time.time > phaseDisableTime) {
            Physics2D.IgnoreLayerCollision(playerLayer, bubbleTriggerLayer, false);
            phaseThruBubbles = false;
            _rigidBody.velocity *= 0.0f;
        }

        // Disable trails at set time
        if (_trail.enabled && Time.time > trailDisableTime) {
            _trail.enabled = false;
        }
    }

    public bool IsAlive() {
        return health != 0;
    }

    public bool AddHealth(int amount) {

        if (amount <= 0) {
            if (Time.time < nextDamageTime) return false;
            nextDamageTime = Time.time + damageCooldown;
            _audio.HurtSFX();
        }

        health += amount;

        if (health < 0) health = 0;
        else if (health > maxHealth) health = maxHealth;
        return true;
    }

    public void ForceAddHealth(int amount) {

        health += amount;

        if (health < 0) health = 0;
        else if (health > maxHealth) health = maxHealth;
    }

    public bool AddCoins(int amount) {

        if (coins + amount < 0) return false;

        if (amount < 0) _audio.CoinUseSFX();
        else _audio.CoinSFX();

        coins += amount;
        if (coins > Util.MAX_INT) coins = Util.MAX_INT;
        return true;
    }

    public void ForceAddCoins(int amount) {

        if (amount < 0) _audio.CoinUseSFX();
        else _audio.CoinSFX();

        coins += amount;
        if (coins < 0) coins = 0;
        else if (coins > Util.MAX_INT) coins = Util.MAX_INT;
    }

    public void PhaseThruBubbles(float duration) {
        Physics2D.IgnoreLayerCollision(playerLayer, bubbleTriggerLayer, true);
        phaseDisableTime = Time.time + duration;
        phaseThruBubbles = true;
    }

    public void TriggerTrails(float duration) {
        _trail.enabled = true;
        trailDisableTime = Time.time + duration;
    }

    public void HealthUpgrade() {
        if (AddCoins(-HealthUpgradePrice())) {
            maxHealth += HEALTH_UPGRADE_UNIT;
            AddHealth(HEALTH_UPGRADE_UNIT);
            healthUpgrades++;
        }
    }

    public string HealthUpgradeTitle() { return maxHealth + ""; }

    public string HealthUpgradeSubtitle() { return healthUpgrades + ""; }

    public string HealthUpgradeDescription() { return "+" + HEALTH_UPGRADE_UNIT + " Health"; }

    public int HealthUpgradePrice() { return Mathf.Min(Util.MAX_INT, Util.Simplify(80 * (1 + healthUpgrades))); }

    public void NextRound() {
        round++;
        if (round > BackgroundScript.bestRound)
            BackgroundScript.bestRound = round;
        // TODO round finish SFX
    }

    public void SoftReset() {
        health = maxHealth;

        _audio.Stop();
    }

    public void Reset() {
        round = DEFAULT_ROUND;
        lives = DEFAULT_LIVES;
        health = DEFAULT_MAX_HEALTH;
        maxHealth = DEFAULT_MAX_HEALTH;
        coins = DEFAULT_COINS;

        nextDamageTime = Time.time;

        phaseThruBubbles = false;
        phaseDisableTime = 0.0f;
        trailDisableTime = 0.0f;

        healthUpgrades = 0;

        _audio.Stop();
    }

    private void OnTriggerStay2D(Collider2D col) {

        if (col.gameObject.layer == bubbleTriggerLayer) {
            Bubble bubble = col.transform.parent.GetComponent<Bubble>();
            BubbleTypes.HitEffects(bubble, this);
            if (IsAlive() && AddHealth(-bubble.damage)) bubble.Pop();
        }
    }
}
