using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimator : MonoBehaviour {

    private SpriteRenderer _spriteRenderer;
    [SerializeField] HealthBar healthBar;
    private char facing;

    private Sprite S_IDLE;
    private Sprite S_UP;
    private Sprite S_DOWN;
    private Sprite S_LEFT;
    private Sprite S_RIGHT;

    private void Awake() {
        _spriteRenderer = GetComponent<SpriteRenderer>();
        facing = 'N';

        S_IDLE = Resources.Load<Sprite>("Sprites/Player/idle");
        S_UP = Resources.Load<Sprite>("Sprites/Player/up");
        S_DOWN = Resources.Load<Sprite>("Sprites/Player/down");
        S_LEFT = Resources.Load<Sprite>("Sprites/Player/left");
        S_RIGHT = Resources.Load<Sprite>("Sprites/Player/right");
    }

    public void Idle() { _spriteRenderer.sprite = S_IDLE; }
    public void FaceUp() { _spriteRenderer.sprite = S_UP; }
    public void FaceDown() { _spriteRenderer.sprite = S_DOWN; }
    public void FaceLeft() { _spriteRenderer.sprite = S_LEFT; }
    public void FaceRight() { _spriteRenderer.sprite = S_RIGHT; }

    public void Face(char dir) {
        if (dir == facing) return;

        facing = dir;
        switch (dir) {
            case 'U': FaceUp(); break;
            case 'D': FaceDown(); break;
            case 'L': FaceLeft(); break;
            case 'R': FaceRight(); break;
            case 'N': Idle(); break;
        }
    }

    public void UpdateColor(Color color) {
        _spriteRenderer.color = color;
        healthBar.UpdateColor(color);
    }
}
