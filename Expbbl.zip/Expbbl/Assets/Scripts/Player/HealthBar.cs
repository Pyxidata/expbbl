using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthBar : MonoBehaviour {

    [SerializeField] GameObject player;
    [SerializeField] GameObject barCover;
    [SerializeField] SpriteRenderer sr;

    private PlayerStats stats;
    private SpriteRenderer coverSr;
    private Vector3 pos;
    private Vector3 scale;

    private void Awake() {
        stats = player.GetComponent<PlayerStats>();
        coverSr = barCover.GetComponent<SpriteRenderer>();
        pos = new Vector3(0, 0, 0);
        scale = new Vector3(1, 1, 1);
    }

    private void Update() {
        scale.x = 1.0f - (float)stats.health / stats.maxHealth;
        barCover.transform.localScale = scale;

        pos.x = (1 - scale.x) * (sr.bounds.size.x / 2.0f);
        barCover.transform.localPosition = pos;
    }

    public void UpdateColor(Color color) {
        sr.color = color;
        coverSr.color = color;
    }
}