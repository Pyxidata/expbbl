using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    // Adjustable values
    public float movementSpeed = 1;
    public float jumpStrength = 1;

    // GameObject properties
    private Rigidbody2D _rigidBody;
    private PlayerStats stats;
    private PlayerAnimator animator;
    private AudioPlayer _audio;
    public const float TELEPORT_HEIGHT = 800f;

    // Physics properties
    private Vector3 moveVel;
    private bool onGround;
    private bool airborne;
    public float tempMovementModifier { get; set; }
    private const float MAX_SPEED = 450f;
    private char facing;

    // Control properties
    private const float HOLD_TRIGGER_BUFFER = 0.5f;
    private float holdTriggerTime;
    private bool attackKeyHeld;
    public bool canAttack;

    // Button control inputs
    public bool upHeld;
    public bool downHeld;
    public bool leftHeld;
    public bool rightHeld;
    public bool slot1Held;
    public bool slot2Held;
    public bool slot3Held;
    public bool slot4Held;
    public bool useUpHeld;
    public bool useDownHeld;
    public bool useLeftHeld;
    public bool useRightHeld;
    public bool reloadHeld;

    // Upgrade properties
    private const int SPEED_UPGRADE_UNIT = 3;
    private const int MAX_SPEED_UPGRADES = 12;
    private int speedUpgrades;
    private const int JUMP_UPGRADE_UNIT = 75;
    private const int MAX_JUMP_UPGRADES = 12;
    private int jumpUpgrades;

    // Weapons
    public PlayerWeapons weapons { get; private set; }

    private void Awake() {

        _rigidBody = GetComponent<Rigidbody2D>();
        stats = GetComponent<PlayerStats>();
        animator = GetComponent<PlayerAnimator>();
        _audio = GetComponent<AudioPlayer>();

        moveVel = new Vector3(0, 0, 0);
        onGround = false;
        tempMovementModifier = 1.0f;
        holdTriggerTime = 0.0f;
        attackKeyHeld = false;
        facing = 'N';
        canAttack = false;
        airborne = false;

        upHeld = false;
        downHeld = false;
        leftHeld = false;
        rightHeld = false;
        slot1Held = false;
        slot2Held = false;
        slot3Held = false;
        slot4Held = false;
        useUpHeld = false;
        useDownHeld = false;
        useLeftHeld = false;
        useRightHeld = false;
        reloadHeld = false;

        speedUpgrades = 0;
        jumpUpgrades = 0;

        weapons = new PlayerWeapons(gameObject);
    }

    private void Update() {

        float speed = Util.Mag(_rigidBody.velocity);
        if (speed > MAX_SPEED) _rigidBody.velocity *= MAX_SPEED / speed;

        if (!stats.IsAlive()) {
            tempMovementModifier = 1.0f;
            return;
        }

        // Face up or down
        if (Input.GetButton("Jump") || upHeld)
            facing = 'U';
        else if (Input.GetButton("Down") || downHeld)
            facing = 'D';

        // Horizontal movement control
        if (Input.GetButton("Horizontal") || rightHeld || leftHeld) {

            float maxSpeed = movementSpeed * tempMovementModifier;
            moveVel = _rigidBody.velocity;

            if (leftHeld) {
                if (moveVel.x > 0) moveVel.x = 0;
                if (moveVel.x < -maxSpeed) moveVel.x = -maxSpeed;
                else moveVel.x += 0.02f * -maxSpeed;
                moveVel.x = -maxSpeed;

            } else if (rightHeld) {
                if (moveVel.x < 0) moveVel.x = 0;
                if (moveVel.x > maxSpeed) moveVel.x = maxSpeed;
                else moveVel.x += 0.02f * maxSpeed;
                moveVel.x = maxSpeed;

            } else
                moveVel.x = Input.GetAxis("Horizontal") * movementSpeed * tempMovementModifier;

            if (moveVel.x < 0 && moveVel.x > _rigidBody.velocity.x || moveVel.x > 0 && moveVel.x < _rigidBody.velocity.x)
                moveVel.x = _rigidBody.velocity.x;

            moveVel.y = _rigidBody.velocity.y;
            _rigidBody.velocity = moveVel;

            if (moveVel.x < 0) facing = 'L';
            else facing = 'R';
        }
        
        // Jump movement control
        if (onGround) {
            if ((Input.GetButton("Jump") || upHeld) && Mathf.Abs(_rigidBody.velocity.y) < 0.01) {
                _rigidBody.AddForce(new Vector2(0, jumpStrength * tempMovementModifier), ForceMode2D.Impulse);
                _audio.JumpSFX();

            } else if (airborne) {
                airborne = false;
            }

        } else {
            airborne = true;
        }

        // Attack control
        int slot = -1;
        if (Input.GetButton("Weapon 1") || slot1Held) slot = 0;
        else if (Input.GetButton("Weapon 2") || slot2Held) slot = 1;
        else if (Input.GetButton("Weapon 3") || slot3Held) slot = 2;
        else if (Input.GetButton("Weapon 4") || slot4Held) slot = 3;

        bool select = false;
        switch (slot) {
            case 0:
                if (weapons.GetToggleMode(0)) {
                    weapons.selectedSlot = 0;
                } else select = true; break;
            case 1:
                if (weapons.GetToggleMode(1)) {
                    weapons.selectedSlot = 1;
                } else select = true; break;
            case 2:
                if (weapons.GetToggleMode(2)) {
                    weapons.selectedSlot = 2;
                } else select = true; break;
            case 3:
                if (weapons.GetToggleMode(3)) {
                    weapons.selectedSlot = 3;
                } else select = true; break;
        }

        char atkDir = AttackControlUpdate(slot, select);

        // Reload weapon
        if (Input.GetButton("Reload") || reloadHeld) {

            if (select) weapons.Reload(slot);
            else weapons.Reload();

        // Player sprite selection
            if (facing != 'N') animator.Face(facing);

        } else {
            if (atkDir != 'N') animator.Face(atkDir);
            else if (facing != 'N') animator.Face(facing);
        }

        tempMovementModifier = 1.0f;
    }

    public void SpeedUpgrade(PlayerStats stats) {
        if (stats.AddCoins(-SpeedUpgradePrice()) && speedUpgrades < MAX_SPEED_UPGRADES) {
            movementSpeed += SPEED_UPGRADE_UNIT;
            speedUpgrades++;
        }
    }

    public void JumpUpgrade(PlayerStats stats) {
        if (stats.AddCoins(-JumpUpgradePrice()) && jumpUpgrades < MAX_JUMP_UPGRADES) {
            jumpStrength += JUMP_UPGRADE_UNIT;
            jumpUpgrades++;
        }
    }

    public string SpeedUpgradeTitle() { return movementSpeed + ""; }

    public string JumpUpgradeTitle() { return jumpStrength + ""; }

    public string SpeedUpgradeSubtitle() { return speedUpgrades + "/" + MAX_SPEED_UPGRADES; }

    public string JumpUpgradeSubtitle() { return jumpUpgrades + "/" + MAX_JUMP_UPGRADES; }

    public string SpeedUpgradeDescription() { return "+" + SPEED_UPGRADE_UNIT + " Speed"; }

    public string JumpUpgradeDescription() { return "+" + JUMP_UPGRADE_UNIT + " Strength"; }

    public int SpeedUpgradePrice() { return Util.Simplify(200 * (Util.CappedExp(speedUpgrades, MAX_SPEED_UPGRADES - 1, Util.MAX_INT / 200))); }

    public int JumpUpgradePrice() { return Util.Simplify(400 * (Util.CappedExp(jumpUpgrades, MAX_JUMP_UPGRADES - 1, Util.MAX_INT / 400))); }

    public void SoftReset() {
        weapons.ReloadAllInstantly();
    }

    public void Reset() {
        _rigidBody.position = new Vector3(0, 18, _rigidBody.position.x);
        _rigidBody.velocity = new Vector3(0, 0, 0);

        moveVel = new Vector3(0, 0, 0);
        onGround = false;
        tempMovementModifier = 1.0f;
        holdTriggerTime = 0.0f;
        attackKeyHeld = false;

        weapons.SetWeapon(0, new PewPew(gameObject));
        weapons.SetWeapon(1, new Empty());
        weapons.SetWeapon(2, new Empty());
        weapons.SetWeapon(3, new Empty());

        speedUpgrades = 0;
        jumpUpgrades = 0;
    }

    public void TeleportToSky() {
        _rigidBody.position = new Vector3(_rigidBody.position.x, TELEPORT_HEIGHT, -1);
    }

    public bool Landed() {
        bool landed = _rigidBody.position.y <= 18 && _rigidBody.position.y >= 0;
        if (landed) _audio.BigLandSFX();
        return landed;
    }

    private char AttackControlUpdate(int slot, bool select) {

        if (!canAttack) return 'N';

        char atkDir = 'N';
        if (select) atkDir = (facing == 'N') ? 'U' : facing;
        else if (Input.GetButton("Attack Up") || useUpHeld) atkDir = 'U';
        else if (Input.GetButton("Attack Down") || useDownHeld) atkDir = 'D';
        else if (Input.GetButton("Attack Left") || useLeftHeld) atkDir = 'L';
        else if (Input.GetButton("Attack Right") || useRightHeld) atkDir = 'R';

        if (holdTriggerTime < Time.time) {

            if (!attackKeyHeld) {
                holdTriggerTime = Time.time + HOLD_TRIGGER_BUFFER;
                attackKeyHeld = true;
            }

            if (atkDir == 'N') {
                holdTriggerTime = 0.0f;
                attackKeyHeld = false;
                return atkDir;
            }

            if (slot == -1) slot = weapons.selectedSlot;
            if (slot == -1) return atkDir; // no weapon held

            switch (atkDir) {
                case 'U': weapons.Use(new Vector2(0.0f, 1.0f), slot); break;
                case 'D': weapons.Use(new Vector2(0.0f, -1.0f), slot); break;
                case 'L': weapons.Use(new Vector2(-1.0f, 0.0f), slot); break;
                case 'R': weapons.Use(new Vector2(1.0f, 0.0f), slot); break;
            }

        } else if (atkDir == 'N') {
            holdTriggerTime = 0.0f;
            attackKeyHeld = false;
        }

        return atkDir;
    }

    private void OnTriggerStay2D(Collider2D other) {
        if (other.gameObject.layer == (1 >> LayerMask.GetMask("Default")))
            onGround = true;
    }

    private void OnTriggerExit2D(Collider2D other) {
        if (other.gameObject.layer == (1 >> LayerMask.GetMask("Default")))
            onGround = false;
    }

    private void OnCollisionEnter2D(Collision2D collision) {
        _audio.LandSFX();
    }

    private int GetRealLayerValue(int gameObjectLayer) {
        return 1 << gameObjectLayer;
    }


}