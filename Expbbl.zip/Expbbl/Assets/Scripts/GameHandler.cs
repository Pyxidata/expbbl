using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameHandler : MonoBehaviour {

    [SerializeField] private GameObject gameOverUI;
    [SerializeField] private GameObject cameraObject;
    [SerializeField] private AudioPlayer _audio;

    private const int STATE_NONE = 0;
    private const int STATE_WON = 10;
    private const int STATE_DEAD = 11;
    private const int STATE_LOST = 12;
    private int state;

    private const float ROUND_END_DELAY = 3.0f; // short delay after player death or victory
    private float nextRoundTime;
    private bool inGame;

    private const float GROUND_REMOVE_DELAY = 2.0f; // short delay before ground disappearing
    private float brickRemoveTime; // bricks disappear half delay prior
    private float groundRemoveTime;
    private bool checkPlayerLanding;

    private const float BUBBLE_SPAWN_DELAY = 1.5f; // short delay for pipes to come put
    private float bubbleSpawnTime;

    private GameObject player;
    private PlayerStats playerStats;
    private PlayerController playerController;
    private PlayerAnimator playerAnimator;
    private BubblesManager bubbles;
    private Environment environment;

    private bool cameraFollowPlayer;
    private float cameraOffset;

    private void Awake() {
        nextRoundTime = 0;
        brickRemoveTime = float.MaxValue;
        groundRemoveTime = float.MaxValue;
        bubbleSpawnTime = float.MaxValue;
        checkPlayerLanding = false;
        cameraOffset = 0;
        inGame = false;

        player = GameObject.Find("Player");
        playerStats = player.GetComponent<PlayerStats>();
        playerController = player.GetComponent<PlayerController>();
        playerAnimator = player.GetComponent<PlayerAnimator>();
        bubbles = GameObject.Find("Bubbles").GetComponent<BubblesManager>();
        environment = GameObject.Find("Environment").GetComponent<Environment>();

        _audio.GameSFX();
        for (int i = 0; i < 5; i++)
            Particle.BrickBreak(new Vector2(-8 + i * 4, PlayerController.TELEPORT_HEIGHT - 4), 20, Environment.DEFAULT_COLOR);
        UpdateColor(Environment.DEFAULT_COLOR);
        Land();
    }

    public void Reset() {
        nextRoundTime = 0;
        brickRemoveTime = float.MaxValue;
        groundRemoveTime = float.MaxValue;
        bubbleSpawnTime = float.MaxValue;
        checkPlayerLanding = false;
        cameraOffset = 0;
        inGame = false;

        environment.Reset();
        UpdateColor(Environment.DEFAULT_COLOR);
        environment.VaryEnvironment();
        _audio.Stop();

        bubbles.Reset();
        playerStats.Reset();
        playerController.Reset();
        Land();
    }

    public void SoftReset() {
        bubbles.Reset();
        playerStats.SoftReset();
        playerController.SoftReset();

        _audio.Stop();
    }

    public void UpdateColor(Color color) {
        playerAnimator.UpdateColor(color);
        environment.UpdateColor(color);
        bubbles.color = color;
    }

    private void Drop() {
        groundRemoveTime = Time.time + GROUND_REMOVE_DELAY;
        brickRemoveTime = Time.time + GROUND_REMOVE_DELAY / 2.0f;
    }

    private void Land() {
        playerController.TeleportToSky();
        environment.SetGroundActive(true);
        environment.SetCeilingActive(false);
        checkPlayerLanding = true;
        cameraFollowPlayer = true;
        cameraOffset = cameraObject.transform.position.y - player.transform.position.y;
        inGame = false;
    }

    private void SpawnBubbles() {
        _audio.PipeMoveSFX();
        environment.PumpPipes();
        bubbleSpawnTime = Time.time + BUBBLE_SPAWN_DELAY;
    }

    private void LateUpdate() {

        // Player following ////////////////////////////////////////////////
        if (cameraFollowPlayer) {
            cameraObject.transform.position = new Vector3(cameraObject.transform.position.x, player.transform.position.y + cameraOffset, cameraObject.transform.position.z);
        }

        // Player dropping/landing and bubble spawning ////////////////////////////////////////////////
        
        // Brick deactivation
        if (Time.time > brickRemoveTime) {
            environment.SetBricksActive(false);
            brickRemoveTime = float.MaxValue;
            _audio.BrickSFX();
        }

        // Ground & particles deactivation
        if (Time.time > groundRemoveTime) {
            environment.SetGroundActive(false);
            groundRemoveTime = float.MaxValue;
            cameraFollowPlayer = true;
            cameraOffset = cameraObject.transform.position.y - player.transform.position.y;
            playerController.canAttack = false;
            _audio.BrickSFX();
            _audio.GroundSFX();
            _audio.FallSFX();
        }

        // Ceiling reactivation
        if (checkPlayerLanding && playerController.Landed()) {
            environment.SetCeilingActive(true);
            checkPlayerLanding = false;
            cameraFollowPlayer = false;
            cameraObject.transform.position = new Vector3(0, 0, cameraObject.transform.position.z);

            SpawnBubbles();
            playerController.canAttack = true;
        }

        // Bubble spawning
        if (Time.time > bubbleSpawnTime) {
            bubbles.SpawnGroup(playerStats.round);
            bubbleSpawnTime = float.MaxValue;
            inGame = true;
            _audio.PipePumpSFX();
        }

        // Game state traversal ////////////////////////////////////////////////
        if (gameOverUI.activeSelf || !inGame) return;

        if (!playerStats.IsAlive() && Time.time > nextRoundTime) {
            nextRoundTime = Time.time + ROUND_END_DELAY;

            // Lost state (no lives left)
            if (playerStats.lives <= ((state == STATE_NONE) ? 1 : 0)) {

                if (state == STATE_LOST) { // final action
                    state = STATE_NONE;
                    gameOverUI.SetActive(true);

                } else { // initial action
                    state = STATE_LOST;
                    playerStats.lives--;
                    BackgroundScript.UpdateSaveData();
                    _audio.GameOverSFX();
                }

                // Dead state (life lost)
            } else {

                if (state == STATE_DEAD) { // final action
                    state = STATE_NONE;
                    SoftReset();
                    SpawnBubbles();

                } else { // initial action
                    state = STATE_DEAD;
                    playerStats.lives--;
                    _audio.RoundLoseSFX();
                }

            }

        // Win state (all bubbles cleared)
        } else if (playerStats.IsAlive() && bubbles.BubblesCleared() && Time.time > nextRoundTime) {
            nextRoundTime = Time.time + ROUND_END_DELAY + GROUND_REMOVE_DELAY;

            if (state == STATE_WON) { // final action
                Land();
                playerController.weapons.ClearParticles();
                state = STATE_NONE;

                if (playerStats.round % 10 == 1) {
                    UpdateColor(environment.NextEnvironment());
                } else environment.VaryEnvironment();

            } else { // initial action
                Drop();
                state = STATE_WON;
                playerStats.NextRound();
                SoftReset();
                BackgroundScript.UpdateSaveData();
                _audio.RoundWinSFX();
            }
        }
    }
}
